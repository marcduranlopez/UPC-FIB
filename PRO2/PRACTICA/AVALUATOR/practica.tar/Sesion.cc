#include "Sesion.hh"
using namespace std;

Sesion::Sesion() {
    identif_sesion = "";    
}


Sesion::Sesion(string s) {
    identif_sesion = s;    
}

void Sesion::leer_string_BinTree() {
    leer_string_BinTree(sesion);
}

void Sesion::leer_string_BinTree(BinTree<string>& sesion) {
    string p;
    cin >> p;
    if (p != "0"){
        BinTree<string> l;
        leer_string_BinTree(l);
        BinTree<string> r;
        leer_string_BinTree(r);
        sesion = BinTree<string>(p,l,r);
  }
}


void Sesion::actualiza_problem_enviables(string& p, map<string,Problema>& problem_enviables, map<string,Problema>& problem_resueltos) {
    BinTree<string> sesion_problem_enviables = buscar_problema_bin(p, sesion);
    actualiza_problem_enviables_bin(sesion_problem_enviables, problem_enviables, problem_resueltos);
        
}


BinTree<string> Sesion::buscar_problema_bin(string& p, BinTree<string>& s) {
    if (s.empty()) return BinTree<string>(); 
    
    if (s.value() == p) {
        BinTree<string> l = s.left();
        BinTree<string> r = s.right();
        return BinTree<string>(p,l,r);
    }
    else {
        BinTree<string> l = s.left();
        BinTree<string> left = buscar_problema_bin(p,l);
        
        if (size(left) == 0) {
        BinTree<string> r = s.right();
        BinTree<string> right = buscar_problema_bin(p,r);
        return right;
        }
        else return left;
    }
}


void Sesion::actualiza_problem_enviables_bin(BinTree<string>& ses, map<string,Problema>& problem_enviables, map<string,Problema>& problem_resueltos) {
    
    if (not ses.empty()) {
        string s = ses.value();
        map<string, Problema>::const_iterator it = problem_resueltos.find(s);
        if (it == problem_resueltos.end())  problem_enviables.insert(make_pair(s, Problema(s)));
       
        else {
        BinTree<string> l = ses.left();
        actualiza_problem_enviables_bin(l, problem_enviables, problem_resueltos);
        BinTree<string> r = ses.right();
        actualiza_problem_enviables_bin(r, problem_enviables, problem_resueltos);
        
        }
    }
}


void Sesion::devolver_problema(map<string,Problema>& problem_enviables, map<string,Problema>& problem_resueltos) {
    actualiza_problem_enviables_bin(sesion, problem_enviables, problem_resueltos);
}


bool Sesion::buscar_problema(string& prob) {
     return buscar_problema(prob, sesion);
}

bool Sesion::buscar_problema(string& p, const BinTree<string>& s) {
    if (s.empty()) return false;
    else {
        BinTree<string> l = s.left();
        BinTree<string> r = s.right();
        return (s.value() == p) or buscar_problema(p, l) or buscar_problema(p, r);
    }
}


vector<string> Sesion::problemas_sesion() {
    vector<string> problemas;
    return problemas_sesion(sesion, problemas);
}


vector<string> Sesion::problemas_sesion(const BinTree<string>& s, vector<string>& problemas) {
    if (not s.empty()) {
        problemas.push_back(s.value());
        BinTree<string> l = s.left();
        problemas_sesion(l, problemas); 
        BinTree<string> r = s.right();
        problemas_sesion(r, problemas);
    }
    return problemas;
}
    

void Sesion::escribir_string_BinTree(const BinTree<string>& sesion) {

    if (not sesion.empty()) {
        string s = sesion.value();
        BinTree<string> l = sesion.left();
        cout << "(";
        escribir_string_BinTree(l); 
        BinTree<string> r = sesion.right(); 
        escribir_string_BinTree(r);
        cout << s << ")";
    }
}

int Sesion::size(BinTree<string> s) {
    if (s.empty()) return 0;
    else return 1 + size(s.left()) + size(s.right()); 
}


void Sesion::escribir()const {
    cout << identif_sesion << " " <<  size(sesion) << " ";
    escribir_string_BinTree(sesion);
    cout << endl;
    
}
