var searchData=
[
  ['actualiza_5fproblem_5fenviables_123',['actualiza_problem_enviables',['../classconj__cursos.html#a34217ff83efe5bcd75c627f6636f7b3b',1,'conj_cursos::actualiza_problem_enviables()'],['../classconj__sesiones.html#a80d0668a5b9993e3f39fadca47211d7f',1,'conj_sesiones::actualiza_problem_enviables()'],['../class_sesion.html#aeb17dc35aa3279f42dab649f0c80a208',1,'Sesion::actualiza_problem_enviables()']]],
  ['actualiza_5fproblem_5fenviables_5fbin_124',['actualiza_problem_enviables_bin',['../class_sesion.html#af09fa9256d9cf1d53c1627bc634633d3',1,'Sesion']]],
  ['agregar_5fproblema_5fresuelto_125',['agregar_problema_resuelto',['../class_usuario.html#ad8de77018dc9ba1cb4f6ea5d5ca2d539',1,'Usuario']]],
  ['alta_5fusuario_126',['alta_usuario',['../classconj__usuarios.html#a6fd2ab489a1e0097807965d89b5b2fb7',1,'conj_usuarios']]]
];
