var searchData=
[
  ['identif_5fsesion_200',['identif_sesion',['../class_sesion.html#a37445804eb7ac4c046492770f61edc85',1,'Sesion']]],
  ['identif_5fsesiones_201',['identif_sesiones',['../class_curso.html#a03ee091f7d8a78e0c477a61223c07119',1,'Curso']]],
  ['intentos_5fproblema_5fp_202',['intentos_problema_p',['../class_usuario.html#af1748d44d8028ec8e813d4013b34c954',1,'Usuario']]]
];
