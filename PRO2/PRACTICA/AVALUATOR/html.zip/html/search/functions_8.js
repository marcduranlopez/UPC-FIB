var searchData=
[
  ['node_170',['Node',['../struct_bin_tree_1_1_node.html#abe7efd4b88937d64f806111b41d49b55',1,'BinTree::Node']]],
  ['nueva_5fsesion_171',['nueva_sesion',['../classconj__sesiones.html#a9635d3e99c59634e39a1f2d59d66df55',1,'conj_sesiones']]],
  ['nuevo_5fcurso_172',['nuevo_curso',['../classconj__cursos.html#a1d9b8515b33dfa2e243afa2ff152bc6e',1,'conj_cursos']]],
  ['nuevo_5fproblema_173',['nuevo_problema',['../classconj__problemas.html#afdb44322c3aee291064ecfdf28bababd',1,'conj_problemas']]]
];
