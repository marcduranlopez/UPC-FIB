var searchData=
[
  ['node_65',['Node',['../struct_bin_tree_1_1_node.html',1,'BinTree&lt; T &gt;::Node'],['../struct_bin_tree_1_1_node.html#abe7efd4b88937d64f806111b41d49b55',1,'BinTree::Node::Node()']]],
  ['nueva_5fsesion_66',['nueva_sesion',['../classconj__sesiones.html#a9635d3e99c59634e39a1f2d59d66df55',1,'conj_sesiones']]],
  ['nuevo_5fcurso_67',['nuevo_curso',['../classconj__cursos.html#a1d9b8515b33dfa2e243afa2ff152bc6e',1,'conj_cursos']]],
  ['nuevo_5fproblema_68',['nuevo_problema',['../classconj__problemas.html#afdb44322c3aee291064ecfdf28bababd',1,'conj_problemas']]],
  ['num_5fcompletados_69',['num_completados',['../class_curso.html#ac7758f78b49791ba493ee26e86fc4afc',1,'Curso']]],
  ['num_5finscritos_70',['num_inscritos',['../class_curso.html#a22fcfd82a42fb7eeb48c5fddd966c64c',1,'Curso']]],
  ['num_5fsesiones_71',['num_sesiones',['../class_curso.html#a7999baa3528b0226f88a7509eb49ab1a',1,'Curso']]]
];
