var searchData=
[
  ['num_5fcompletados_205',['num_completados',['../class_curso.html#ac7758f78b49791ba493ee26e86fc4afc',1,'Curso']]],
  ['num_5finscritos_206',['num_inscritos',['../class_curso.html#a22fcfd82a42fb7eeb48c5fddd966c64c',1,'Curso']]],
  ['num_5fsesiones_207',['num_sesiones',['../class_curso.html#a7999baa3528b0226f88a7509eb49ab1a',1,'Curso']]]
];
