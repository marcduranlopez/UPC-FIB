var searchData=
[
  ['p_5fenviables_175',['p_enviables',['../class_usuario.html#a49faca17d28c201c2d6a525479d85b39',1,'Usuario']]],
  ['p_5fresueltos_176',['p_resueltos',['../class_usuario.html#a7750b3558f812a3e330009f04b262d60',1,'Usuario']]],
  ['pertenece_177',['pertenece',['../classconj__cursos.html#a42234a4f1870e5bcc5ad8c26f4e81175',1,'conj_cursos']]],
  ['problema_178',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#aea2c69d4cc77b257da1f319b85281e79',1,'Problema::Problema(string p)']]],
  ['problemas_5fenviables_179',['problemas_enviables',['../classconj__usuarios.html#ab39fa55e793d0560d99559c718420459',1,'conj_usuarios']]],
  ['problemas_5fresueltos_180',['problemas_resueltos',['../classconj__usuarios.html#aa30b4c5798ddbcacf43321520884dc5d',1,'conj_usuarios']]],
  ['problemas_5fsesion_181',['problemas_sesion',['../classconj__sesiones.html#a8ed7e0bd1e4c184977536f7bda19d6ac',1,'conj_sesiones::problemas_sesion()'],['../class_sesion.html#aec29a71502eed911976beda2ed452139',1,'Sesion::problemas_sesion(const BinTree&lt; string &gt; &amp;s, vector&lt; string &gt; &amp;problemas)'],['../class_sesion.html#a3e659167a06be45eddd16109adbe843a',1,'Sesion::problemas_sesion()']]]
];
