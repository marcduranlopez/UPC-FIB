var searchData=
[
  ['operator_3c_72',['operator&lt;',['../class_problema.html#a37891f4dac3a72597d85addd47a14d00',1,'Problema']]]
];
