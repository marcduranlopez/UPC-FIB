var searchData=
[
  ['aux_193',['aux',['../classconj__problemas.html#ae224f966c0eff2317b64a7282637f279',1,'conj_problemas']]]
];
