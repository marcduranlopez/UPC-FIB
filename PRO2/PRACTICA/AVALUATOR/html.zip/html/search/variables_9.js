var searchData=
[
  ['sesion_214',['sesion',['../class_sesion.html#a49b3008463dbab40f2db04ea9fd3450a',1,'Sesion']]],
  ['sesiones_215',['sesiones',['../classconj__sesiones.html#a2b1e900d8393770fd27ad1467ad14055',1,'conj_sesiones']]]
];
