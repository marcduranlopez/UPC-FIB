var searchData=
[
  ['decrementar_5finscritos_25',['decrementar_inscritos',['../class_usuario.html#a6f5b7ae16c56e455b85bd41d205a79e6',1,'Usuario']]],
  ['decrementar_5fusuario_26',['decrementar_usuario',['../classconj__cursos.html#a0a124e03220977519b006fe9ebb5b1fb',1,'conj_cursos::decrementar_usuario()'],['../class_curso.html#aaafa87da92ed3c782eaa8dbfda88cf81',1,'Curso::decrementar_usuario()']]],
  ['devolver_5fproblema_27',['devolver_problema',['../classconj__sesiones.html#a54eed5f599e5166c396e71c4065177a5',1,'conj_sesiones::devolver_problema()'],['../class_sesion.html#afe57d80eeed1067043bdd7169b60feb3',1,'Sesion::devolver_problema()']]]
];
