var searchData=
[
  ['env_5fexito_5fproblem_197',['env_exito_problem',['../class_problema.html#acc416511b107a152cb200295c0277941',1,'Problema']]],
  ['env_5ftotales_5fproblem_198',['env_totales_problem',['../class_problema.html#acf84f2ebaa13e0777c5b05de966da64d',1,'Problema']]],
  ['env_5ftotales_5fusuario_199',['env_totales_usuario',['../class_usuario.html#a9ca62e4de9060a5188ec50d748dec211',1,'Usuario']]]
];
