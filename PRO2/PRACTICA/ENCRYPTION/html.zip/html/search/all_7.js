var searchData=
[
  ['main_41',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['map_5fmensajes_42',['MAP_mensajes',['../class_cjt__mensajes.html#a2ff62968c3f5fa1afac5aa6bc52f2bf2',1,'Cjt_mensajes']]],
  ['matriz_43',['Matriz',['../_rejilla_8hh.html#a422bf39ef07f56574e3b9155ca4f6e99',1,'Rejilla.hh']]],
  ['matriz_5fchar_44',['Matriz_char',['../_rejilla_8cc.html#a400013ea5d17c5f4cabec65ec9d5b9d3',1,'Rejilla.cc']]],
  ['matriz_5fint_45',['Matriz_int',['../_rejilla_8cc.html#a1ad1a387801ddc24baf4ea5e33fc209c',1,'Rejilla.cc']]],
  ['mensaje_46',['Mensaje',['../class_mensaje.html',1,'Mensaje'],['../class_mensaje.html#a7b8b4ca08f400fef32eaffeec00f65b3',1,'Mensaje::Mensaje()'],['../class_mensaje.html#aa514483f5da6c9669f6f014037e991cf',1,'Mensaje::Mensaje(string idm)'],['../class_mensaje.html#a2274f79e62490a0d65c2c60f115ea842',1,'Mensaje::mensaje()']]],
  ['mensaje_2ecc_47',['Mensaje.cc',['../_mensaje_8cc.html',1,'']]],
  ['mensaje_2ehh_48',['Mensaje.hh',['../_mensaje_8hh.html',1,'']]],
  ['mensaje_5fvalido_49',['mensaje_valido',['../class_rejilla.html#a998bb4cad33ffbdead20c6b7042e6c4e',1,'Rejilla']]]
];
