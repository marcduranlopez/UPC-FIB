var searchData=
[
  ['patron_82',['Patron',['../class_patron.html',1,'']]]
];
