var searchData=
[
  ['validacion_68',['validacion',['../class_cjt__rejillas.html#aaa05e92b74f77094f768edbf8c8bbc1a',1,'Cjt_rejillas::validacion()'],['../class_rejilla.html#ac5b238fb87f2dbcf39796d048d6b92ab',1,'Rejilla::validacion()']]],
  ['vec_5fpatrones_69',['VEC_patrones',['../class_cjt__patrones.html#a605e14866237f745c10631d64df42c4b',1,'Cjt_patrones']]],
  ['vec_5frejillas_70',['VEC_rejillas',['../class_cjt__rejillas.html#a18d5723ee7b6aea59d8b0d7020ac84bb',1,'Cjt_rejillas']]]
];
