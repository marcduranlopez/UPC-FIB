var searchData=
[
  ['plantilla_140',['Plantilla',['../class_rejilla.html#a5a3496d8bbcc91b73863ad476e0732f3',1,'Rejilla']]],
  ['posiciones_141',['posiciones',['../class_rejilla.html#aeb12b91480a48b096c1b555cf2fb59f1',1,'Rejilla']]]
];
