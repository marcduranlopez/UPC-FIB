var searchData=
[
  ['main_116',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mensaje_117',['Mensaje',['../class_mensaje.html#a7b8b4ca08f400fef32eaffeec00f65b3',1,'Mensaje::Mensaje()'],['../class_mensaje.html#aa514483f5da6c9669f6f014037e991cf',1,'Mensaje::Mensaje(string idm)']]],
  ['mensaje_5fvalido_118',['mensaje_valido',['../class_rejilla.html#a998bb4cad33ffbdead20c6b7042e6c4e',1,'Rejilla']]]
];
