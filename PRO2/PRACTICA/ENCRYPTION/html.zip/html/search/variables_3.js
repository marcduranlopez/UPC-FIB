var searchData=
[
  ['map_5fmensajes_138',['MAP_mensajes',['../class_cjt__mensajes.html#a2ff62968c3f5fa1afac5aa6bc52f2bf2',1,'Cjt_mensajes']]],
  ['mensaje_139',['mensaje',['../class_mensaje.html#a2274f79e62490a0d65c2c60f115ea842',1,'Mensaje']]]
];
