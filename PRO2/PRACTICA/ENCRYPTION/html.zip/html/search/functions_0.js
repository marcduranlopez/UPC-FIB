var searchData=
[
  ['borra_5fmensaje_90',['borra_mensaje',['../class_cjt__mensajes.html#a6dfc23a9f32e1d53a3b1c9be95163a48',1,'Cjt_mensajes']]]
];
