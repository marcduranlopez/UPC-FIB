var searchData=
[
  ['cjt_5fmensajes_91',['Cjt_mensajes',['../class_cjt__mensajes.html#ae41d6f14fc0292300c9f4ce1a0897abc',1,'Cjt_mensajes']]],
  ['cjt_5fpatrones_92',['Cjt_patrones',['../class_cjt__patrones.html#ac169314f2961663c592f353a27c6bbf2',1,'Cjt_patrones']]],
  ['cjt_5frejillas_93',['Cjt_rejillas',['../class_cjt__rejillas.html#adad13a62f5448b994b766eba12d4a09c',1,'Cjt_rejillas']]],
  ['codificar_94',['codificar',['../class_patron.html#a86a3b4f919d7de8c3d6ce2ad2a371a9d',1,'Patron::codificar()'],['../class_rejilla.html#a4ef291efeb7eaa66676a7af571b69432',1,'Rejilla::codificar()']]],
  ['codificar_5fguardado_5fpatron_95',['codificar_guardado_patron',['../class_cjt__patrones.html#aa306e6819883d7d30270c02bd6494212',1,'Cjt_patrones']]],
  ['codificar_5fguardado_5frejilla_96',['codificar_guardado_rejilla',['../class_cjt__rejillas.html#a73bea369cb2e6c4f1ac5e4cc32adad16',1,'Cjt_rejillas']]],
  ['codificar_5fpatron_97',['codificar_patron',['../class_cjt__patrones.html#a69727a831d7b91f98ec403c5e7d254bb',1,'Cjt_patrones']]],
  ['codificar_5frejilla_98',['codificar_rejilla',['../class_cjt__rejillas.html#a5c9a3fa170b037a7429a52387861ad16',1,'Cjt_rejillas']]],
  ['consistencia_99',['consistencia',['../class_cjt__rejillas.html#ae6cc5a9f18ead9d364b660a36071bafe',1,'Cjt_rejillas']]],
  ['crear_5fmosaico_100',['crear_mosaico',['../class_patron.html#a47a88b97cd1dd42685d80faa4f24313f',1,'Patron']]],
  ['crear_5fplantilla_101',['crear_plantilla',['../class_rejilla.html#ac74b1ff94f512692e3d9acc42ff98432',1,'Rejilla']]]
];
