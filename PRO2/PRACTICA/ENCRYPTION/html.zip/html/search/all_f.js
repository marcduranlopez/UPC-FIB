var searchData=
[
  ['x_73',['x',['../struct_bin_tree_1_1_node.html#a9c268d4af01559e8237dbeb5bd19af91',1,'BinTree::Node']]]
];
