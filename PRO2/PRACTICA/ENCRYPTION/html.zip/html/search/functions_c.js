var searchData=
[
  ['validacion_129',['validacion',['../class_cjt__rejillas.html#aaa05e92b74f77094f768edbf8c8bbc1a',1,'Cjt_rejillas::validacion()'],['../class_rejilla.html#ac5b238fb87f2dbcf39796d048d6b92ab',1,'Rejilla::validacion()']]]
];
