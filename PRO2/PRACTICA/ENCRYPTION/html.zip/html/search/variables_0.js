var searchData=
[
  ['b_130',['b',['../class_patron.html#a107898743e635a2162721a74083f7313',1,'Patron']]],
  ['bt_5fmosaico_131',['BT_mosaico',['../class_patron.html#a1f53d53ccc103b928de638622043fc88',1,'Patron']]],
  ['bt_5fmsj_132',['BT_msj',['../class_patron.html#aa408cb01ccc08f44093f8edab140e600',1,'Patron']]],
  ['bt_5fpatron_133',['BT_patron',['../class_patron.html#a94c419f771bcf0d03325bf8f161b2843',1,'Patron']]]
];
