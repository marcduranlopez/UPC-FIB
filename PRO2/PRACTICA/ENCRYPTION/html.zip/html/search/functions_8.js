var searchData=
[
  ['obtener_5fmensaje_122',['obtener_mensaje',['../class_cjt__mensajes.html#a7152f1ea034c5ec07ef86d83efe29195',1,'Cjt_mensajes::obtener_mensaje()'],['../class_mensaje.html#ae57d41599bd7ef4456d912ca9bc20f74',1,'Mensaje::obtener_mensaje()']]]
];
