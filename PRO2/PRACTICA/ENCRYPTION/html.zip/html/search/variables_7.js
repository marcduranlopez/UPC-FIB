var searchData=
[
  ['tam_153',['tam',['../class_rejilla.html#ae4115481c7d576d9d9a8f2f3ef37ea10',1,'Rejilla']]]
];
