var searchData=
[
  ['decodificar_22',['decodificar',['../class_patron.html#ad3ea736ee0f9c200178b58b915232efe',1,'Patron::decodificar()'],['../class_rejilla.html#ab7a00b7719e620dc3185cd4502a702bb',1,'Rejilla::decodificar()']]],
  ['decodificar_5fpatron_23',['decodificar_patron',['../class_cjt__patrones.html#a3567443e5f0da1145c3ae58600b0bd7f',1,'Cjt_patrones']]],
  ['decodificar_5frejilla_24',['decodificar_rejilla',['../class_cjt__rejillas.html#ae9e2bd65fe2ff22811458acee2444114',1,'Cjt_rejillas']]],
  ['dim_25',['dim',['../class_rejilla.html#a4786770c78ba0dca247cd9ccbafa0ef5',1,'Rejilla']]]
];
