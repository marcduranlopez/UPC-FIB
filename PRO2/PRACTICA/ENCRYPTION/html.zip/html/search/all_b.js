var searchData=
[
  ['rejilla_60',['Rejilla',['../class_rejilla.html',1,'Rejilla'],['../class_rejilla.html#a0d4c2d54277ee3862d53d0f673ac8783',1,'Rejilla::Rejilla()']]],
  ['rejilla_2ecc_61',['Rejilla.cc',['../_rejilla_8cc.html',1,'']]],
  ['rejilla_2ehh_62',['Rejilla.hh',['../_rejilla_8hh.html',1,'']]],
  ['rellenar_5fparametros_63',['rellenar_parametros',['../class_mensaje.html#a49c9a429d8199b7b782402e9390f1934',1,'Mensaje::rellenar_parametros()'],['../class_patron.html#a3a599b8dff198a28904a02ced2c296c9',1,'Patron::rellenar_parametros()'],['../class_rejilla.html#aed14f0373e4e1b26050e0ec925e4d9c5',1,'Rejilla::rellenar_parametros()']]],
  ['restar_5fmosaico_64',['restar_mosaico',['../class_patron.html#ab6154d47e3b42acb4e98fadd2e92b174',1,'Patron']]],
  ['rotar_5f90_65',['rotar_90',['../class_rejilla.html#ad1ca179639bbc065eb52514d335acbda',1,'Rejilla']]]
];
