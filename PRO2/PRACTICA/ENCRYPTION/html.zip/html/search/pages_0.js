var searchData=
[
  ['encriptacion_20de_20mensajes_3a_20plataforma_20para_20encriptar_20y_20desencriptar_20mensajes_20por_20permutacion_20y_20sustitucion_2e_148',['ENCRIPTACION DE MENSAJES: Plataforma para encriptar y desencriptar mensajes por permutacion y sustitucion.',['../index.html',1,'']]]
];
