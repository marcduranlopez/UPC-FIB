var searchData=
[
  ['matriz_145',['Matriz',['../_rejilla_8hh.html#a422bf39ef07f56574e3b9155ca4f6e99',1,'Rejilla.hh']]],
  ['matriz_5fchar_146',['Matriz_char',['../_rejilla_8cc.html#a400013ea5d17c5f4cabec65ec9d5b9d3',1,'Rejilla.cc']]],
  ['matriz_5fint_147',['Matriz_int',['../_rejilla_8cc.html#a1ad1a387801ddc24baf4ea5e33fc209c',1,'Rejilla.cc']]]
];
