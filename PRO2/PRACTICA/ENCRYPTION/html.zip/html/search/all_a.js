var searchData=
[
  ['patron_54',['Patron',['../class_patron.html',1,'Patron'],['../class_patron.html#a8664d13f6847795f5e480b758d66ff88',1,'Patron::Patron()']]],
  ['patron_2ecc_55',['Patron.cc',['../_patron_8cc.html',1,'']]],
  ['patron_2ehh_56',['Patron.hh',['../_patron_8hh.html',1,'']]],
  ['plantilla_57',['Plantilla',['../class_rejilla.html#a5a3496d8bbcc91b73863ad476e0732f3',1,'Rejilla']]],
  ['posiciones_58',['posiciones',['../class_rejilla.html#aeb12b91480a48b096c1b555cf2fb59f1',1,'Rejilla']]],
  ['program_2ecc_59',['program.cc',['../program_8cc.html',1,'']]]
];
