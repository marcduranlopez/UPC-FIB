var searchData=
[
  ['b_0',['b',['../class_patron.html#a107898743e635a2162721a74083f7313',1,'Patron']]],
  ['borra_5fmensaje_1',['borra_mensaje',['../class_cjt__mensajes.html#a6dfc23a9f32e1d53a3b1c9be95163a48',1,'Cjt_mensajes']]],
  ['bt_5fmosaico_2',['BT_mosaico',['../class_patron.html#a1f53d53ccc103b928de638622043fc88',1,'Patron']]],
  ['bt_5fmsj_3',['BT_msj',['../class_patron.html#aa408cb01ccc08f44093f8edab140e600',1,'Patron']]],
  ['bt_5fpatron_4',['BT_patron',['../class_patron.html#a94c419f771bcf0d03325bf8f161b2843',1,'Patron']]]
];
