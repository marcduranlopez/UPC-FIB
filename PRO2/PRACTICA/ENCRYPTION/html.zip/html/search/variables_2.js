var searchData=
[
  ['idm_135',['idm',['../class_mensaje.html#a47148948169031f7c121b9dc4272ab7f',1,'Mensaje']]],
  ['idp_136',['idp',['../class_patron.html#a8d3521f060e2646cd349aead26825665',1,'Patron']]],
  ['idr_137',['idr',['../class_rejilla.html#a922a94529cb96a9b3afe80b09db74111',1,'Rejilla']]]
];
