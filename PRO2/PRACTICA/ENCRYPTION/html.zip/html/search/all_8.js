var searchData=
[
  ['nueva_5frejilla_50',['nueva_rejilla',['../class_cjt__rejillas.html#a6faaa3114a25bc133fb2ff32a40b5cb2',1,'Cjt_rejillas']]],
  ['nuevo_5fmensaje_51',['nuevo_mensaje',['../class_cjt__mensajes.html#af50aac65d9c990ef3adfd9d6f6a92935',1,'Cjt_mensajes']]],
  ['nuevo_5fpatron_52',['nuevo_patron',['../class_cjt__patrones.html#ab9efedd70f12de2e2e4f5302874221d9',1,'Cjt_patrones']]]
];
