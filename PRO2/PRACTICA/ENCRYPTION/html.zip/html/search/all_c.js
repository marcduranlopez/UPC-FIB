var searchData=
[
  ['sumar_5fmosaico_66',['sumar_mosaico',['../class_patron.html#a591154379e87ff0320de0fe1e39d809c',1,'Patron']]]
];
