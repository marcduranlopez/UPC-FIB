var searchData=
[
  ['girar_5frejilla_30',['girar_rejilla',['../class_rejilla.html#ad747d99025090ca25f5a5c93accf2525',1,'Rejilla']]]
];
