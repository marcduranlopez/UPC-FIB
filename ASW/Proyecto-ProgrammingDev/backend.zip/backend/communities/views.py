from django.shortcuts import render, redirect, get_object_or_404
from .models import Community
from posts.models import Post, Comment
from posts.views import applySortFilter, getSortFilter, getSavedPosts, getCommunityFilter, getDataFilter, applyDataFilter, paginate
from django.http import *
from django.contrib import messages
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.decorators import authentication_classes, permission_classes
from posts.serializers import CommentSerializer
from posts.api.serializers import PostListSerializer


sort_filters = ['new', 'old', 'best', 'commented']


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_community_posts(request, community_id):
    try:
        community = Community.objects.get(id=community_id)
    except Community.DoesNotExist:
        return Response({'error': 'Community does not exist'}, status=status.HTTP_404_NOT_FOUND)

    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    posts = Post.objects.filter(community=community)
    posts = applySortFilter("publicaciones", sortType, posts)

    posts = paginate(posts, request)
    serializer = PostListSerializer(posts, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_community_comments(request, community_id):
    
    try:
        community = Community.objects.get(id=community_id)
    except Community.DoesNotExist:
        return Response({'error': 'Community does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    posts = Post.objects.filter(community=community)
    comments = Comment.objects.filter(post__in=posts)
    comments = applySortFilter("comentarios", sortType, comments)
    
    comments = paginate(comments, request)
    serializer = CommentSerializer(comments, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)





def communities(request):
    
    filter = getCommunityFilter(request)
    if filter == "subscribed":
        if request.user.is_authenticated:
            list_communities = Community.objects.filter(subscribers=request.user).order_by('-id')
        else:
            return redirect('/error') 
    else:
        list_communities = Community.objects.all().order_by('-id')

    context = {
        'list_communities': list_communities, 
        'type': "communities"
        }
    
    return render(request, 'communities/communities.html', context) 
        
 

def create_community(request):
    if request.user.is_authenticated:
        return render(request, 'communities/create_community.html')
    else:
        return redirect('/error')
    


def do_community(request):
    if request.method == 'POST':
        # Obtener datos del formulario
        id = request.POST.get('id')
        name = request.POST.get('nombre')
        banner = request.FILES.get('banner')
        avatar = request.FILES.get('avatar')
        created_by = request.user.username


         # Verificar si ya existe una comunidad con el mismo ID
        if Community.objects.filter(id=id).exists():
            messages.error(request, "Ya existe una comunidad con ese ID. Por favor, elige otro ID.")
            return render(request, 'communities/create_community.html', {'messages': messages.get_messages(request)})
        
        
        # Crear una instancia de la comunidad
        community = Community(
            id=id,
            name=name,
            banner=banner,
            avatar=avatar,
            created_by=created_by,
        )
        community.save()

        # Redirigir a la página de la comunidad creada
        return  render(request, 'communities/view_community.html', {'community': community})


    return render(request, 'communities/create_community.html')




def view_community(request, community_id):
    
    # Recuperar la comunidad por su nombre
    community = get_object_or_404(Community, id=community_id)
    
    sortType = getSortFilter(request)
    dataType = getDataFilter(request)
    stuff = applyDataFilter(dataType)
    
    if dataType == "publicaciones":
        stuff = stuff.filter(community=community)
        stuff = applySortFilter(dataType, sortType, stuff)
        saved_posts =  getSavedPosts(request.user)
        context = { 'posts': stuff }
        if request.user.is_authenticated:
            saved_posts = getSavedPosts(request.user)
            context['saved_posts'] = saved_posts
        
    else:
        posts = Post.objects.filter(community=community)
        stuff = stuff.filter(post__in=posts)
        stuff = applySortFilter(dataType, sortType, stuff)
        context = { 'comments': stuff }
            
    context['community'] = community
    return render(request, 'communities/view_community.html', context)



#TODO: refactor and use on posts
def subscribe(request, community_id):
    if not request.user.is_authenticated:
        return redirect('/error')
    # Recuperar la comunidad por su nombre
    community = get_object_or_404(Community, id=community_id)

    # Agregar al usuario actual a la lista de suscriptores de la comunidad
    user = request.user
    community.subscribers.add(user)
    
    list_communities = Community.objects.all().order_by('-id')
    # Redirigir de regreso a la página de las comunidades
    return render(request, 'communities/communities.html', {'list_communities': list_communities, 'type': "communities"}) 


def unsubscribe(request, community_id):
    # Recuperar la comunidad por su nombre
    community = get_object_or_404(Community, id=community_id)

    # Eliminar al usuario actual de la lista de suscriptores de la comunidad
    user = request.user
    community.subscribers.remove(user)

    list_communities = Community.objects.all().order_by('-id')
    # Redirigir de regreso a la página de las comunidades
    return render(request, 'communities/communities.html', {'list_communities': list_communities, 'type': "communities"})
