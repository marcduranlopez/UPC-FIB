from django.db import models
from django.contrib.auth.models import User
#from users.models import User

# Create your models here.
class Community(models.Model):
    id = models.CharField(primary_key=True, max_length=100)
    name = models.CharField(max_length=100, null=True, blank= True)
    banner = models.ImageField(upload_to='banners/', null=True, blank=True)
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    subscribers = models.ManyToManyField(User, related_name='subscribed_Community', blank=True)
    
    numPosts = models.IntegerField(default=0)
    numComments = models.IntegerField(default=0)
    
    created_by = models.CharField(max_length=255, blank=False, default="admin")
    
    def save(self, *args, **kwargs):
        if not self.name:
            self.name = 'S/N'
        super(Community, self).save(*args, **kwargs)
        
        
    @classmethod
    def create_community(cls, community_data):
        required_fields = ['id',]
        for field in required_fields:
            if not community_data.get(field, ''):
                raise ValueError(f"{field} is required and cannot be blank.")

        numPosts = community_data.get('numPosts', 0) or 0
        numComments = community_data.get('numComments', 0) or 0
        
        created_by = community_data.get('created_by')
        if not created_by:
            created_by = "anonymous"
        

        community = cls.objects.create(
            id=community_data.get('id'),
            created_by=created_by,
            name=community_data.get('name'),
            banner=community_data.get('banner'),
            avatar=community_data.get('avatar'),
            numPosts=numPosts,
            numComments=numComments,
        )

        return community