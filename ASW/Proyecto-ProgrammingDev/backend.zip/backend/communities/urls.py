from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from communities import views

urlpatterns = [
    path("api/communities/<community_id>/comments/", views.get_community_comments, name="get_community_comments"),
    path("api/communities/<community_id>/posts/", views.get_community_posts, name="get_community_posts"),
    path("communities/", views.communities, name="communities"),  
    path("create_community/", views.create_community, name="create_community"),
    path("do_community/", views.do_community, name="do_community"),
    path("communities/<community_id>", views.view_community, name="view_community"), 
    path("subscribe/<community_id>", views.subscribe, name="subscribe"),
    path("unsubscribe/<community_id>", views.unsubscribe, name="unsubscribe"),
    
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
