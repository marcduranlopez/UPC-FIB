from rest_framework.routers import DefaultRouter
from .views import CommunityViewSet

router_communities = DefaultRouter()

router_communities.register(prefix='communities', basename='communities', viewset=CommunityViewSet)

