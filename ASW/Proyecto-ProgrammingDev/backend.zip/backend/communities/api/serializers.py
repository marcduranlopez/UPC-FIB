from rest_framework import serializers
from communities.models import Community

class CommunitySerializer(serializers.ModelSerializer):
    numSubscribers = serializers.SerializerMethodField('get_num_subscribers')

    class Meta:
        model = Community
        fields = ['id', 'name', 'banner', 'avatar', 'numPosts', 'numComments', 'created_by', 'subscribers', 'numSubscribers',]
        
    def get_num_subscribers(self, community):
        return community.subscribers.count()

class CommunityCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Community
        exclude = ['numPosts', 'numComments', 'created_by', 'subscribers',]
        
class CommunityListSerializer(serializers.ModelSerializer):
    numSubscribers = serializers.SerializerMethodField('get_num_subscribers')

    class Meta:
        model = Community
        fields = ['id','name', 'subscribers', 'numSubscribers', 'numPosts', 'numComments']
        read_only_fields = ['id', 'name', 'subscribers', 'numSubscribers', 'numPosts', 'numComments']

    def get_num_subscribers(self, community):
        return community.subscribers.count()

class SubscribeCommunitySerializer(serializers.ModelSerializer):
    subscribers = serializers.StringRelatedField(many=True)
    class Meta:
        model = Community
        fields = ['subscribers']

    def update(self, instance, validated_data):
        user = self.context['request'].user

        if self.context['view'].action == 'subscribeCom':
            instance.subscribers.add(user)
        elif self.context['view'].action == 'unsubscribeCom':
            instance.subscribers.remove(user)

        return instance
