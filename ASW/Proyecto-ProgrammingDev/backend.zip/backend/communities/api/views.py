from posts.models import Post
from posts.api.serializers import PostSerializer
from django.http import *
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework import status
from communities.models import Community
from .serializers import CommunitySerializer, CommunityCreateSerializer, SubscribeCommunitySerializer, CommunityListSerializer
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly

class CommunityViewSet(viewsets.ModelViewSet):
    serializer_class = CommunitySerializer
    queryset = Community.objects.all()
    
    permission_classes = [IsAuthenticatedOrReadOnly] 
    authentication_classes = [TokenAuthentication]
    pagination_class = PageNumberPagination
    pagination_class.page_size = 10
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    


    def get_serializer_class(self):
        if self.action == 'create':
            return CommunityCreateSerializer
        elif self.action == 'list':
            return CommunityListSerializer
        elif self.action in ['subscribeCom', 'unsubscribeCom']:
            return SubscribeCommunitySerializer  
        return CommunitySerializer


    def create(self, request, *args, **kwargs):
        user = getattr(request.user, 'profile', None)
        if user is not None:
            community_data = request.data.copy()
            community_data['created_by'] = user.username
            
            community = Community.create_community(community_data)
            serializer = self.get_serializer(community)
            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        else:
            # Manejar el caso donde no se encuentra un perfil asociado al usuario
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)


    def retrieve(self, request, pk=None):
        community = self.get_object()
        serializer = self.get_serializer(community)
        
        return Response({'community': serializer.data})

        
    @action(detail=True, methods=['get', 'post'], url_path='subscribe')
    def subscribeCom(self, request, pk=None):
        community = self.get_object()
        serializer = self.get_serializer(community, data={}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()  # Esto activará la lógica del SubscribeCommunitySerializer
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, headers=headers)



    @action(detail=True, methods=['get', 'post'], url_path='unsubscribe')
    def unsubscribeCom(self, request, pk=None):
        community = self.get_object()
        serializer = self.get_serializer(community, data={}, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()  # Esto activará la lógica del SubscribeCommunitySerializer
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, headers=headers)
            

    @action(detail=False, methods=['get'])
    def subscribed_communities(self, request):
        user = self.request.user

        if user.is_anonymous:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
        else:
            subscribed_communities = Community.objects.filter(subscribers=user)
            serializer = self.get_serializer(subscribed_communities, many=True)
            headers = self.get_success_headers(serializer.data)
            return Response({'subscribed_communities': serializer.data, 'type': "subscribed_communities"}, headers=headers)
