from django.contrib import admin
from .models import Community

# Register your models here.
admin.site.register(Community)
