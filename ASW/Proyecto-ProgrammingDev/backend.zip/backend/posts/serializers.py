from rest_framework import serializers
from .models import Comment, Vote, SavedComment
from .api.serializers import PostSerializer

class CommentSerializer(serializers.ModelSerializer):
    
    post = PostSerializer()

    class Meta:
        model = Comment
        fields = '__all__'

class VoteSerializer(serializers.ModelSerializer):
    
    comment = CommentSerializer()
    
    class Meta:
        model = Vote
        fields = '__all__'

class SavedCommentSerializer(serializers.ModelSerializer):
    
    comment = CommentSerializer()
    
    class Meta:
        model = SavedComment
        fields = '__all__'


