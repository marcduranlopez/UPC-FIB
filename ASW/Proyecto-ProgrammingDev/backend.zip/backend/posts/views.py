from django.shortcuts import render, redirect
from django.http import *
from .models import *
from communities.models import Community
from users.models import Profile
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.decorators import authentication_classes, permission_classes
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .serializers import CommentSerializer, SavedCommentSerializer, VoteSerializer
from posts.api.serializers import PostSerializer

community_filters = ['local','subscribed']
dataType_filters = ['publicaciones', 'comentarios']
sort_filters = ['new', 'old', 'best', 'commented']
vote_values = ['positive', 'negative']

def applyCommunitiesFilter(dataType, filter, user, stuff):
    
    if filter == "subscribed":
        communities = Community.objects.filter(subscribers=user)
        if dataType == "publicaciones":
            return stuff.filter(community__in=communities)
        else:
            posts = Post.objects.filter(community__in=communities)
            return stuff.filter(post__in=posts)
    else:
        return stuff.all()

def applySortFilter(dataType, sortType, stuff):
    if sortType == "new":
        return stuff.order_by('-created_at')
    elif sortType == "old":
        return stuff.order_by('created_at')
    elif sortType == "commented":
        if dataType == "publicaciones":
            return stuff.order_by('-total_comments')
        else:
            return stuff.order_by('-total_responses')
    else:
        return stuff.order_by('-total_votes')
    
def applyDataFilter(dataType):
    
    if dataType == "publicaciones":
        return Post.objects
    else:
        return Comment.objects

def getCommunityFilter(request):
    return request.GET.get("filter", "local")

def getDataFilter(request):
    return request.GET.get("dataType", "publicaciones")
    
def getSortFilter(request):
    return request.GET.get("order", "new")

def getSavedPosts(user):
    saved_posts = SavedPost.objects.filter(user=user.username)
    posts_asociados = [saved_post.post for saved_post in saved_posts]
    return posts_asociados

def getSavedComments(user):
    saved_comments = SavedComment.objects.filter(user=user.username)
    comentarios_asociados = [saved_comment.comment for saved_comment in saved_comments]
    return comentarios_asociados

def paginate(stuff, request):
    paginator = Paginator(stuff, 20)  
    page_number = request.query_params.get('page')
    if not (page_number is None) and paginator.num_pages < int(page_number):
        return []
    try:
        page_obj = paginator.get_page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    return page_obj

    
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['POST'])
def create_comment(request, post_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        post = Post.objects.get(id=post_id)
    except Post.DoesNotExist:
        return Response({'error': 'Post does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    extra_fields = set(request.data.keys()) - {'body'}
    
    if extra_fields:
        return Response({'error': f'Unexpected field(s): {", ".join(extra_fields)}'}, status=status.HTTP_400_BAD_REQUEST)
    
    if 'body' not in request.data:
        return Response({'error': 'The body field is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if not isinstance(request.data['body'], str):
        return Response({'error': 'The body field must be a string'}, status=status.HTTP_400_BAD_REQUEST)
    
    post.total_comments = post.total_comments + 1
    post.community.numComments = post.community.numComments + 1
    post.save()
    post.community.save()
   
    profile = Profile.objects.get(user=request.user)
    profile.num_comentaris = profile.num_comentaris + 1
    profile.save()
    
    comment = Comment(user_owner = profile.username, body = request.data['body'], post = post, positive_votes = 1, total_votes = 1)
    comment.save()
    vote_object = Vote(comment=comment, user=request.user.username, type="positive")
    vote_object.save()
    
    serializer = CommentSerializer(comment)
    return Response(serializer.data, status=status.HTTP_201_CREATED)


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['POST'])
def create_response(request, comment_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    extra_fields = set(request.data.keys()) - {'body'}
    if extra_fields:
        return Response({'error': f'Unexpected field(s): {", ".join(extra_fields)}'}, status=status.HTTP_400_BAD_REQUEST)
    
    if 'body' not in request.data:
        return Response({'error': 'The body field is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if not isinstance(request.data['body'], str):
        return Response({'error': 'The body field must be a string'}, status=status.HTTP_400_BAD_REQUEST)
    
    comment.total_responses = comment.total_responses + 1
    comment.post.total_comments = comment.post.total_comments + 1
    comment.post.community.numComments = comment.post.community.numComments + 1
    comment.post.save()
    comment.save()
    comment.post.community.save()
            
    profile = Profile.objects.get(user=request.user)
    profile.num_comentaris = profile.num_comentaris + 1
    profile.save()
            
    response = Comment(user_owner = profile.username, body = request.data['body'], post = comment.post, positive_votes = 1, 
                       total_votes = 1, response_to = comment, indentation = comment.indentation + 1)
    response.save()
    vote_object = Vote(comment=response, user=request.user.username, type="positive")
    vote_object.save()
    
    serializer = CommentSerializer(response)
    return Response(serializer.data, status=status.HTTP_201_CREATED)
    
    
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])     
@api_view(['DELETE'])
def delete_comment(request, comment_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    if comment.user_owner != request.user.username:
        return Response({'error': 'You cannot delete a comment created by another person'}, status=status.HTTP_403_FORBIDDEN)
    
    comment.post.total_comments = comment.post.total_comments - (1 + comment.total_responses)
    comment.post.community.numComments = comment.post.community.numComments - (1 + comment.total_responses)
    comment.post.save()
    comment.post.community.save()
    profile = Profile.objects.get(user=request.user)
    profile.num_comentaris = profile.num_comentaris - (1 + comment.total_responses)
    profile.save()
    comment.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)
    
 
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['POST'])
def vote_comment(request, comment_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    extra_fields = set(request.data.keys()) - {'type'}
    if extra_fields:
        return Response({'error': f'Unexpected field(s): {", ".join(extra_fields)}'}, status=status.HTTP_400_BAD_REQUEST)
    
    if 'type' not in request.data:
        return Response({'error': 'The type field is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if request.data['type'] not in vote_values:
        return Response({'error': 'The type field can only have this two values: positive or negative'}, status=status.HTTP_400_BAD_REQUEST)
    
    type = request.data['type']
    
    try:   
        vote = Vote.objects.get(comment=comment, user=request.user.username)
    except Exception:
        vote = None
    
    if vote:
        
        if vote.type != type:    
            
            vote.type = type
            vote.save()  
            if type == "positive":
                comment.positive_votes = comment.positive_votes + 1
                comment.negative_votes = comment.negative_votes - 1
            elif type == "negative":
                comment.positive_votes = comment.positive_votes - 1
                comment.negative_votes = comment.negative_votes + 1  
        else:
            vote.delete()
                    
            if vote.type == "positive":
                comment.positive_votes = comment.positive_votes - 1
            elif vote.type == "negative":
                comment.negative_votes = comment.negative_votes - 1  
                    
    else:
        vote_object = Vote(comment=comment, user=request.user.username, type=type)
        vote_object.save()
            
        if type == "positive":
            comment.positive_votes = comment.positive_votes + 1
        elif type == "negative":
            comment.negative_votes = comment.negative_votes + 1
            
    comment.total_votes = comment.positive_votes - comment.negative_votes
    comment.save()
    serializer = CommentSerializer(comment)
    return Response(serializer.data, status=status.HTTP_200_OK)



@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['PUT'])
def update_comment(request, comment_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    if comment.user_owner != request.user.username:
        return Response({'error': 'You cannot edit a comment created by another person'}, status=status.HTTP_403_FORBIDDEN)
    
    extra_fields = set(request.data.keys()) - {'body'}
    if extra_fields:
        return Response({'error': f'Unexpected field(s): {", ".join(extra_fields)}'}, status=status.HTTP_400_BAD_REQUEST)
    
    if 'body' not in request.data:
        return Response({'error': 'The body field is required'}, status=status.HTTP_400_BAD_REQUEST)
    
    if not isinstance(request.data['body'], str):
        return Response({'error': 'The body field must be a string'}, status=status.HTTP_400_BAD_REQUEST)
    
    comment.body = request.data['body']
    comment.save()
    serializer = CommentSerializer(comment)
    return Response(serializer.data, status=status.HTTP_200_OK)
    
    
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['POST'])
def save_comment(request, comment_id):
    
    if not request.auth:
            return Response({'error': 'Token de autenticación no proporcionado.'}, status=status.HTTP_401_UNAUTHORIZED)
    
    try:
        comment = Comment.objects.get(id=comment_id)
    except Comment.DoesNotExist:
        return Response({'error': 'Comment does not exist'}, status=status.HTTP_404_NOT_FOUND)
       
    try:   
        saved_comment = SavedComment.objects.get(comment=comment, user=request.user.username)
    except Exception:
        saved_comment = None

    if saved_comment:
        saved_comment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
            
    else:
        saved_comment_object = SavedComment(comment=comment, user=request.user.username)
        saved_comment_object.save()
        serializer = SavedCommentSerializer(saved_comment_object)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_comments(request):
    
    communitiesType = request.query_params.get('communitiesType', 'local') 
    if communitiesType not in community_filters:
        return Response({'error': 'The communitiesType parameter can only have this two values: local or subscribed'}, status=status.HTTP_400_BAD_REQUEST)
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    comments = applyCommunitiesFilter("comentarios", communitiesType, request.user, Comment.objects)
    comments = applySortFilter("comentarios", sortType, comments)
    
    comments = paginate(comments, request)
    serializer = CommentSerializer(comments, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_posts(request):
    
    communitiesType = request.query_params.get('communitiesType', 'local') 
    if communitiesType not in community_filters:
        return Response({'error': 'The communitiesType parameter can only have this two values: local or subscribed'}, status=status.HTTP_400_BAD_REQUEST)
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    posts = applyCommunitiesFilter("publicaciones", communitiesType, request.user, Post.objects)
    posts = applySortFilter("publicaciones", sortType, posts)
    
    posts = paginate(posts, request)
    serializer = PostSerializer(posts, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)
    
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_post_comments(request, post_id):
    
    try:
        post = Post.objects.get(id=post_id)
    except Post.DoesNotExist:
        return Response({'error': 'Post does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    comments = Comment.objects.filter(response_to=None, post=post)
    comments = applySortFilter("comentarios", sortType, comments)
    comentarios_anidados = []
    
    if sortType == "best":
        sortType = "-total_votes"
    elif sortType == "new":
        sortType = "-created_at"
    elif sortType == "old":
        sortType = "created_at"
    else:
        sortType = "-total_responses"
    
    for comment in comments:
        comentarios_anidados.append(comment)
        comentarios_anidados.extend(comment.obtener_respuestas_anidadas(sortType))
    
    serializer = CommentSerializer(comentarios_anidados, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)
    
    
    
def home(request):

    filter = getCommunityFilter(request)
    if filter == "subscribed" and not request.user.is_authenticated:
        return redirect("/error")
    dataType = getDataFilter(request)
    sortType = getSortFilter(request)
    
    stuff = applyDataFilter(dataType)
    stuff = applyCommunitiesFilter(dataType, filter, request.user, stuff)
    stuff = applySortFilter(dataType, sortType, stuff)
    
    if dataType == "publicaciones":
        
        context = { 'posts': stuff }
        if request.user.is_authenticated:
            saved_posts = getSavedPosts(request.user)
            context['saved_posts'] = saved_posts
            
    else:
        context = { 'comments': stuff }
    
    return render(request, 'posts/blog.html', context)
    


def create_post(request):
    
    communities = Community.objects.all().order_by('id')
    
    if request.user.is_authenticated:
        type = 'create'
        return render(request, 'posts/post_form.html', {'communities': communities, 'type': type})
    
    return redirect('/error')
    
  
    
def do_post(request):
    
    if request.method == "POST":
        if request.user.is_authenticated:
            user_owner = request.user.username
        else:
            return redirect('/error')
        url = request.POST['url']
        title = request.POST['title']
        description = request.POST['description']
        total_comments = 0

        positive_votes = 0
        negative_votes = 0
        total_votes = positive_votes - negative_votes
        
        try:
            communityId = request.POST['community']
        except Exception:
            communityId = None
               
        try: 
            communityObject = Community.objects.get(id=communityId)    
        except Exception:
            communityObject = None
                    
        if title and communityObject:
            new_post = Post(user_owner = user_owner, title = title, 
                            url = url, description = description,
                            total_comments = total_comments,
                            positive_votes = positive_votes,
                            negative_votes = negative_votes,
                            total_votes = total_votes, community = communityObject)

            new_post.save()
            
            communityObject.numPosts = communityObject.numPosts + 1
            communityObject.save()
            
            return redirect('/see_post/' + str(new_post.id) + '/')
        
    return render(request, 'posts/create_post.html') 



def edit(request, id): 
    
    if request.user.is_authenticated:
        post = Post.objects.get(id=id)
        if request.user.username == post.user_owner:
            communities = Community.objects.filter().exclude(id=post.community.id)
            
            community = post.community
            community.numPosts = community.numPosts - 1
            community.save()
            
            type = 'edit'
            return render(request, 'posts/post_form.html', {'post': post, 'communities': communities, 'source': 'community', 'type': type})
    
    return redirect('/error')



def do_edit(request, id):
    
    if request.method == "POST":
        url = request.POST['url']
        title = request.POST['title']
        description = request.POST['description']
        
        try:
            communityId = request.POST['community']
        except Exception:
            communityId = None
               
        try: 
            communityObject = Community.objects.get(id=communityId)    
        except Exception:
            communityObject = None
            
        post = Post.objects.get(id=id)
        #poner fecha de modificacion?
        if url:
            post.url = url
        else:
            try: 
                if request.POST['delete_url']:
                    post.url = ""
            except Exception:
                post.url = post.url
            
        
        if title:
            post.title = title
            
        if description:
            post.description = description
            
        if communityObject:
            post.community = communityObject
        
        post.save()  
        
        community = post.community
        community.numPosts = community.numPosts +1 
        community.save()      
        
        return redirect('/see_post/' + str(id) + '/')



def see_post(request, id):
    
    try:
        post = Post.objects.get(id=id)
    except:
        return redirect("/error")
    comments = Comment.objects.filter(response_to=None, post=post)
    sortType = getSortFilter(request)
    comments = applySortFilter("comentarios", sortType, comments)
    comentarios_anidados = []
    
    if type == "best":
        sortType = "-total_votes"
    elif type == "new":
        sortType = "-created_at"
    elif type == "old":
        sortType = "created_at"
    else:
        sortType = "-total_responses"
    
    for comment in comments:
        comentarios_anidados.append(comment)
        comentarios_anidados.extend(comment.obtener_respuestas_anidadas(sortType))
    
    saved_posts =  getSavedPosts(request.user)
    
    context = {
         'post': post, 
         'comments': comentarios_anidados,
         'saved_posts': saved_posts,
         }
    return render(request, 'posts/post.html', context)

    
    
def do_vote(request, id):
    type = request.GET.get("vote")
    source = request.GET.get("source")
    post = Post.objects.get(id=id)
    vote(request=request, type=type, post=post)
    return redirect(source) 



def vote(request, type, post):
    if request.user.is_authenticated:
          
        try:   
            vote = Vote.objects.get(post=post, user=request.user.username)
        except Exception:
            vote = None
        
        if vote:
            if vote.type == type:
                vote.delete()
                
                if type == "positive":
                    post.positive_votes = post.positive_votes - 1
                elif type == "negative":
                    post.negative_votes = post.negative_votes - 1
                
            else:
                vote.type = type
                vote.save()
                
                if type == "positive":
                    post.positive_votes = post.positive_votes + 1
                    post.negative_votes = post.negative_votes - 1
                elif type == "negative":
                    post.positive_votes = post.positive_votes - 1
                    post.negative_votes = post.negative_votes + 1
                    
        else:
            vote_object = Vote(post=post, user=request.user.username, type=type)
            vote_object.save()
            
            if type == "positive":
                post.positive_votes = post.positive_votes + 1
            elif type == "negative":
                post.negative_votes = post.negative_votes + 1
            
        post.total_votes = post.positive_votes - post.negative_votes
        post.save()



def do_delete(request, id):
    source = request.GET.get("source")
    
    if request.user.is_authenticated:
        post = Post.objects.get(id=id)
        if request.user.username == post.user_owner:
            
            community = post.community
            community.numPosts = community.numPosts - 1
            community.save()
            
            post.delete()
            return redirect(source)

    return redirect('/error')
    


def do_save(request, id):
    source = request.GET.get("source")
    
    if request.user.is_authenticated:
        post = Post.objects.get(id=id) 
        
        try:   
            saved_post = SavedPost.objects.get(post=post, user=request.user.username)
        except Exception:
            saved_post = None


        if saved_post:
            saved_post.delete()
            
        else:
            saved_post_object = SavedPost(post=post, user=request.user.username)
            saved_post_object.save()
            
    return redirect(source)
            
            
            
def show_user(request, id, user):

    profile = Profile.objects.get(username=user)
    user_object = profile.user
    return redirect('/users/' + str(user_object.id) + '/')



def do_vote_comment(request, id):
    
    if not request.user.is_authenticated:
        return redirect('/error')
    
    source = request.GET.get("source")
    type = request.GET.get("vote")
    comment = Comment.objects.get(id=id) 
        
    try:   
        vote = Vote.objects.get(comment=comment, user=request.user.username)
    except Exception:
        vote = None
        
    if vote:
        if vote.type == type:
            vote.delete()
                
            if type == "positive":
                comment.positive_votes = comment.positive_votes - 1
            elif type == "negative":
                comment.negative_votes = comment.negative_votes - 1
                
        else:
            vote.type = type
            vote.save()
                
            if type == "positive":
                comment.positive_votes = comment.positive_votes + 1
                comment.negative_votes = comment.negative_votes - 1
            elif type == "negative":
                comment.positive_votes = comment.positive_votes - 1
                comment.negative_votes = comment.negative_votes + 1
                    
    else:
        vote_object = Vote(comment=comment, user=request.user.username, type=type)
        vote_object.save()
            
        if type == "positive":
            comment.positive_votes = comment.positive_votes + 1
        elif type == "negative":
            comment.negative_votes = comment.negative_votes + 1
            
    comment.total_votes = comment.positive_votes - comment.negative_votes
    comment.save()
    
    return redirect(source)



def do_reply(request, id):
    
    if not request.user.is_authenticated:
        return redirect('/error')
    
    if request.method == 'POST':
        
        source = request.POST.get("source")
        replyType = request.POST.get("reply")
        
        if replyType == "comentar":
            
            post = Post.objects.get(id=id)
            post.total_comments = post.total_comments + 1
            post.community.numComments = post.community.numComments + 1
            post.save()
            post.community.save()
            
            profile = Profile.objects.get(user=request.user)
            profile.num_comentaris = profile.num_comentaris + 1
            profile.save()
            body = request.POST.get("response")
            
            
            comment = Comment(user_owner = profile.username, body = body, post = post, 
                              positive_votes = 1, negative_votes = 0, total_votes = 1,
                              total_responses = 0)
            comment.save()
            vote_object = Vote(comment=comment, user=request.user.username, type="positive")
            vote_object.save()
            
        elif replyType == "responder":
            
            comment = Comment.objects.get(id=id)
            comment.total_responses = comment.total_responses + 1
            comment.post.total_comments = comment.post.total_comments + 1
            comment.post.community.numComments = comment.post.community.numComments + 1
            comment.post.save()
            comment.save()
            comment.post.community.save()
            
            profile = Profile.objects.get(user=request.user)
            profile.num_comentaris = profile.num_comentaris + 1
            profile.save()
            
            body = request.POST.get("response")
            
            response = Comment(user_owner = profile.username, body = body, post = comment.post, 
                               positive_votes = 1, negative_votes = 0, total_votes = 1, 
                               response_to = comment, total_responses = 0, indentation = comment.indentation + 1)
            response.save()
            vote_object = Vote(comment=response, user=request.user.username, type="positive")
            vote_object.save()
            
        elif replyType == "guardar":
            
            comment = Comment.objects.get(id=id)
            if comment.user_owner != request.user.username:
                return redirect('/error')
            comment.body = request.POST.get("response")
            comment.save()
    
    return redirect(source)



def do_delete_comment(request, id):
    
    if not request.user.is_authenticated:
        return redirect('/error')
    source = request.GET.get("source")
    comment = Comment.objects.get(id=id)
    if comment.user_owner != request.user.username:
        return redirect('/error')
    comment.post.total_comments = comment.post.total_comments - (1 + comment.total_responses)
    comment.post.community.numComments = comment.post.community.numComments - (1 + comment.total_responses)
    comment.post.save()
    comment.post.community.save()
    profile = Profile.objects.get(user=request.user)
    profile.num_comentaris = profile.num_comentaris - (1 + comment.total_responses)
    profile.save()
    comment.delete()
    
    return redirect(source)



def do_save_comment(request, id):
    
    if not request.user.is_authenticated:
        return redirect('/error')
    comment = Comment.objects.get(id=id) 
        
    try:   
        saved_comment = SavedComment.objects.get(comment=comment, user=request.user.username)
    except Exception:
        saved_comment = None

        if saved_comment:
            saved_comment.delete()
            
        else:
            saved_comment_object = SavedComment(comment=comment, user=request.user.username)
            saved_comment_object.save()
            
    return HttpResponse('Solicitud exitosa', status=204)
            


def error(request):
    return render(request, 'posts/error.html')

def clear_all():
    Post.objects.all().delete()
    Community.objects.all().delete()

def get_saved_posts_for_blog(username):
    posts = Post.objects.all().order_by('-id')
    saved_posts = SavedPost.objects.all()
    
    saved_posts_in_blog = {}
    
    for post in posts:
        for saved_post in saved_posts:
            if post == saved_post.post and username == saved_post.user:
                saved_posts_in_blog[post] = post
    
    return saved_posts_in_blog

def order_by_filters(request, user_id=None):
    filter = request.GET.get('filter')

    
    show_subscribed = filter == "subscribed"
    show_local = filter == "local"
    
    if not show_subscribed and not show_local:
        show_local = True

    if not request.user.is_authenticated and show_subscribed:
        return redirect('/error')
     
    source = request.path
    users = re.match('/users/(?P<id>\d+)/?$', source)
            
    if source == "/communities/":
        context = get_filtered_communities(request, show_local, show_subscribed)
        return render(request, 'communities/communities.html', context) 
    elif users:
        context = get_filtered_posts_in_user(request, show_local, show_subscribed, user_id)
        return render(request, 'profile.html', context)
    else:
        context = get_filtered_posts(request, show_local, show_subscribed)
        return render(request, 'posts/blog.html', context)
    
def get_filtered_communities(request, show_local, show_subscribed):
    if show_subscribed:
        if request.user.is_authenticated:
            list_communities = Community.objects.filter(subscribers=request.user).order_by('-id')
        else:
            return redirect('/error') #TODO error, haz login
        
    elif show_local:
        list_communities = Community.objects.all().order_by('-id')
    else:
        list_communities = Community.objects.all().order_by('-id')

    context = {
            'list_communities': list_communities, 
            'type': "communities"
            }
    
    return context   

def get_filtered_posts_in_user(request, show_local, show_subscribed, id):
    # Recupera el objeto de perfil de usuario usando el ID proporcionado en la URL
    profile = get_object_or_404(Profile, user_id=id)
    posts = {}
    
    if show_subscribed:
        if request.user.is_authenticated:
            list_communities = Community.objects.filter(subscribers=request.user).order_by('-id')
            for post in Post.objects.all().filter(user_owner=profile.username):
                for community in list_communities:
                    if post.community == community:
                        posts[post] = post
        else:
            return redirect('/error') #TODO error, haz login
    
    elif show_local:
        posts = Post.objects.all().filter(user_owner=profile.username).order_by('-id')
    else:
        posts = Post.objects.all().filter(user_owner=profile.username).order_by('-id')
    
    
    saved_posts = get_saved_posts_for_blog(request.user.username)
    context = {
        'profile': profile,
        'posts': posts,  # Agrega la lista de publicaciones/comentarios filtrada y ordenada aquí
        'saved_posts': saved_posts,
        'type': 'users',
    }
    # Renderiza la plantilla y pasa el perfil como contexto
    return context

def order_posts(request):
    source = request.GET.get("source")
    type = request.GET.get("order")
    
    if type is None:
        source = request.path
    
    community = re.match('/communities/(\d+)(?:/(.*))?/?$', source)
    user = re.match('/users/(\d+)(?:/(.*))?/?$', source)

    if community:      
        if type is None:
            return redirect('/communities/' + str(community_id) + '/')
        
        community_id = community.group(1)
        return redirect('/communities/' + str(community_id) + '/' + 'sort_type/?sort_type=' + type)
    elif user:
        if type is None:
            redirect('/users/' + str(user_id) + '/')
        
        user_id = user.group(1)
        return redirect('/users/' + str(user_id) + '/' + 'sort_type/?sort_type=' + type)
    else:
        if type is None:
            return redirect('/')
        
        posts = posts_by_order_type(type=type)
        saved_posts =  get_saved_posts_for_blog(request.user.username)        
        context = {
            'posts': posts, 
            'saved_posts': saved_posts
            }
        return render(request, 'posts/blog.html', context)
    
def posts_by_order_type(type, filter_condition=None):
    if type == "new":
        posts = Post.objects.all().order_by('-created_at')
    elif type == "old":
        posts = Post.objects.all().order_by('created_at')
    elif type == "commented":
        posts = Post.objects.all().order_by('-total_comments')
    elif type == "best":
        posts = Post.objects.all().order_by('-total_votes')
    else:
        posts = Post.objects.all()
        
    if filter_condition:
        posts = posts.filter(**filter_condition)
    
    return posts

def order_comments(request, id):
    post = Post.objects.get(id=id)
    
    order = request.GET.get("order")
    
    if order == "new":
        return render(request, 'posts/post.html', {'post': post})
    
    elif order == "old":
        return render(request, 'posts/post.html', {'post': post})
    
    elif order == "best":
        return render(request, 'posts/post.html', {'post': post})
    
    return render(request, 'posts/post.html', {'post': post})
