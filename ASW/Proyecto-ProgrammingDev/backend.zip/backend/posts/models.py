from django.db import models
from communities.models import Community
from django.utils import timezone

class Post(models.Model):
    id = models.BigAutoField(primary_key=True)
    user_owner = models.CharField(max_length=255, blank=False)
    title = models.CharField(max_length=255, blank=False)
    url = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    
    total_comments = models.IntegerField( default=0)
    
    positive_votes = models.IntegerField( default=0)
    negative_votes = models.IntegerField( default=0)
    total_votes = models.IntegerField( default=0)
    
    created_at = models.DateTimeField(default=timezone.now)
    
    community = models.ForeignKey(Community, on_delete=models.CASCADE)

    @classmethod
    def create_post(cls, post_data):
        
        required_fields = ['title']
        for field in required_fields:
            if not post_data.get(field, ''):
                raise ValueError(f"{field} is required and cannot be blank.")

        user_owner = post_data.get('user_owner')
        if not user_owner:
            user_owner = "anonymous"
            
        community_id = post_data.get('community')

        # Verificamos si community_id es válido y existe
        try:
            community = Community.objects.get(id=str(community_id))
        except Community.DoesNotExist:
            raise ValueError(f"Community with ID {community_id} does not exist.")
        
        created_at_str = post_data.get('created_at', '')
        created_at = timezone.datetime.fromisoformat(created_at_str) if created_at_str else timezone.now()        
        
        total_comments = post_data.get('total_comments', 0) or 0
        positive_votes = post_data.get('positive_votes', 0) or 0
        negative_votes = post_data.get('negative_votes', 0) or 0
        total_votes = post_data.get('total_votes', 0) or 0
        
        try:
            total_comments = int(total_comments)
            positive_votes = int(positive_votes)
            negative_votes = int(negative_votes)
            total_votes = int(total_votes)
        except ValueError:
            raise ValueError("Invalid integer value for one of the fields.")

        post = cls.objects.create(
            user_owner=user_owner,
            title=post_data.get('title'),
            url=post_data.get('url', ''),
            description=post_data.get('description', ''),
            total_comments=total_comments,
            positive_votes=positive_votes,
            negative_votes=negative_votes,
            total_votes=total_votes,
            created_at=created_at,
            community=community,
        )

        return post

class Comment(models.Model):
    user_owner = models.CharField(max_length=255, blank=False)
    body = models.TextField(blank=False, null=False)
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    positive_votes = models.IntegerField( default=0)
    negative_votes = models.IntegerField( default=0)
    total_votes = models.IntegerField( default=0)
    response_to = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True)
    total_responses = models.IntegerField( default=0)
    created_at = models.DateTimeField(default=timezone.now)
    indentation = models.IntegerField( default=0)
    
    def obtener_respuestas_anidadas(self, sortType):
        respuestas_anidadas = []
        respuestas = Comment.objects.filter(response_to=self)
        respuestas = respuestas.order_by(sortType)
        for respuesta in respuestas:
            respuestas_anidadas.append(respuesta)
            respuestas_anidadas.extend(respuesta.obtener_respuestas_anidadas(sortType))
        return respuestas_anidadas

class Vote(models.Model):
    class Meta:
        unique_together = (('post', 'user'),('comment', 'user'),)

    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True, blank=True)
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, null=True, blank=True)
    user = models.CharField(max_length=255, blank=False)
    type = models.CharField(max_length=10, blank=False, null=False)

class SavedComment(models.Model):
    class Meta:
        unique_together = (('comment', 'user'),)

    comment = models.ForeignKey(Comment, on_delete=models.CASCADE)
    user = models.CharField(max_length=255, blank=False)

class SavedPost(models.Model):
    class Meta:
        unique_together = (('post', 'user'),)
    
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    user = models.CharField(max_length=255, blank=False)
