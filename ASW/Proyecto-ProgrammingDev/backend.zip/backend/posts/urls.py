from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from posts import views

urlpatterns = [
    path("api/get_posts/", views.get_posts, name="get_posts"),
    path("api/comments/", views.get_comments, name="get_comments"),
    path("api/comments/<comment_id>/responses/", views.create_response, name="create_response"),
    path("api/comments/<comment_id>/vote/", views.vote_comment, name="vote_comment"),
    path("api/posts/<post_id>/comments/", views.create_comment, name="create_comment"),
    path("api/comments/<comment_id>/save/", views.save_comment, name="save_comment"),
    path("api/comments/<comment_id>/", views.update_comment, name="update_comment"),
    path("api/coments/<comment_id>/", views.delete_comment, name="delete_comment"),
    path("api/posts/<post_id>/coments/", views.get_post_comments, name="get_posts_comments"),
    path("", views.home, name="home"),
    path("create_post/", views.create_post, name="create_post"),
    path("do_post/", views.do_post, name="do_post"),
    path("edit/<id>/", views.edit, name="edit"),
    path("do_delete_comment/<id>", views.do_delete_comment, name="do_delete_comment"),
    path("do_save_comment/<id>", views.do_save_comment, name="do_save_comment"),
    path("do_vote_comment/<id>", views.do_vote_comment, name="do_vote_comment"),
    path("do_reply/<id>", views.do_reply, name="do_reply"),
    path("do_edit/<id>/", views.do_edit, name="do_edit"),
    path("see_post/<id>/", views.see_post, name="see_post"),
    path("do_vote/<id>/", views.do_vote, name="do_vote"),
    path("do_delete/<id>/", views.do_delete, name="do_delete"),
    path("do_save/<id>/", views.do_save, name="do_save"),
    path("post/<id>/user/<user>", views.show_user, name="show_user"),
    path("comment/<id>/user/<user>", views.show_user, name="show_user"),
    path("error/", views.error, name="error"),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

