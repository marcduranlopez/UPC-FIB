from rest_framework import serializers
from posts.models import Post
from communities.api.serializers import CommunitySerializer

class PostSerializer(serializers.ModelSerializer):
    
    community = CommunitySerializer()
    class Meta:
        model = Post
        fields = '__all__'

class PostListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ['id', 'user_owner', 'title', 'url', 'description', 'total_comments', 'positive_votes', 'negative_votes', 'total_votes', 'created_at', 'community']

class PostCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        exclude = ['user_owner', 'total_comments', 'positive_votes', 'negative_votes', 'total_votes', 'created_at']
