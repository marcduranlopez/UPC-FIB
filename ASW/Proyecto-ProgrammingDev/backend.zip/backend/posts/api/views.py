from rest_framework.decorators import action
from django.shortcuts import render, redirect
from rest_framework import viewsets, status
from .serializers import PostSerializer, PostListSerializer, PostCreateSerializer
from rest_framework import viewsets, status
from rest_framework.response import Response
from django.http import *
from posts.models import *
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.decorators import action


class PostView(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    models = Post
    permission_classes = [IsAuthenticatedOrReadOnly] 
    authentication_classes = [TokenAuthentication]
    pagination_class = PageNumberPagination
    pagination_class.page_size = 10
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]

    ordering_fields = ['created_at', 'total_votes', 'total_comments']

    filterset_fields = ['user_owner']

    def get_serializer_class(self):
        if self.action == 'list':
            return PostListSerializer
        elif self.action == 'create' or self.action == 'update':    
            return PostCreateSerializer
        return PostSerializer

    def create(self, request, *args, **kwargs):
        user_profile = getattr(request.user, 'profile', None)

        if user_profile is not None:
            post_data = request.data.copy()
            post_data['user_owner'] = user_profile.username

            post = Post.create_post(post_data)
            post.community.numPosts = post.community.numPosts + 1
            post.community.save()

            serializer = self.get_serializer(post)

            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
        else:
            # Manejar el caso donde no se encuentra un perfil asociado al usuario
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)


        
        

    @action(detail=True, methods=['get', 'post'], url_path='like')
    def like_post(self, request, pk=None):
        user_profile = getattr(request.user, 'profile', None)
        
        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
        
        else: 
            instance = self.get_object()
            try:
                vote = Vote.objects.get(post=instance, user=user_profile.username)
            except Exception:
                vote = None

            if request.method == 'GET' and user_profile is not None and vote is not None:
                serializer = self.get_serializer(instance)
                headers = self.get_success_headers(serializer.data)
                if vote.type == "positive":
                    return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)
                else:
                     return Response(serializer.data, status=status.HTTP_404_NOT_FOUND, headers=headers)

            elif request.method == 'GET' and user_profile is not None and vote is None:
                serializer = self.get_serializer(instance)
                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_404_NOT_FOUND, headers=headers)

            if user_profile is not None and vote is not None:
                if vote.type == 'positive':
                    vote.delete()
                    instance.positive_votes = instance.positive_votes - 1
                elif vote.type == 'negative':
                    vote.type = 'positive'
                    vote.save()
                    instance.positive_votes = instance.positive_votes + 1
                    instance.negative_votes = instance.negative_votes - 1
                    
                instance.total_votes = instance.positive_votes - instance.negative_votes    
                instance.save()
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
                    
            elif user_profile is not None:
                vote_object = Vote(post=instance, user=user_profile.username, type="positive")
                vote_object.save()
                instance.positive_votes = instance.positive_votes + 1
                instance.total_votes = instance.positive_votes - instance.negative_votes
                instance.save()
                
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
                
        
        
        

    @action(detail=True, methods=['get', 'post'], url_path='dislike')
    def dislike_post(self, request, pk=None):
        user_profile = getattr(request.user, 'profile', None)
        
        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
        
        else: 
            instance = self.get_object()
            try:
                vote = Vote.objects.get(post=instance, user=user_profile.username)
            except Exception:
                vote = None

            if request.method == 'GET' and user_profile is not None and vote is not None:
                serializer = self.get_serializer(instance)
                headers = self.get_success_headers(serializer.data)
                if vote.type == "negative":
                    return Response(serializer.data, status=status.HTTP_200_OK, headers=headers)
                else:
                     return Response(serializer.data, status=status.HTTP_404_NOT_FOUND, headers=headers)

            elif request.method == 'GET' and user_profile is not None and vote is None:
                serializer = self.get_serializer(instance)
                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_404_NOT_FOUND, headers=headers)
            
            if user_profile is not None and vote is not None:
                if vote.type == 'negative':
                    vote.delete()
                    instance.negative_votes = instance.negative_votes - 1
                elif vote.type == 'positive':
                    vote.type = 'negative'
                    vote.save()
                    instance.positive_votes = instance.positive_votes - 1
                    instance.negative_votes = instance.negative_votes + 1
                
                instance.total_votes = instance.positive_votes - instance.negative_votes
                instance.save()
                    
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
                    
            elif user_profile is not None:
                vote_object = Vote(post=instance, user=user_profile.username, type="negative")
                vote_object.save()
                instance.negative_votes = instance.negative_votes + 1
                instance.total_votes = instance.positive_votes - instance.negative_votes
                instance.save()
                
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)


    def update(self, request, *args, **kwargs):
        user_profile = getattr(request.user, 'profile', None)
        community = request.data.get('community')
        instance = self.get_object()
        user_owner = getattr(instance, 'user_owner', None)
        
        
        
        if user_profile.username != user_owner: 
            return Response({"error": "Token no autorizado"}, status=status.HTTP_401_UNAUTHORIZED)
        
        elif user_profile is not None:
            if community != instance.community.id:
                community_object = Community.objects.get(id=community)
                community_object.numPosts = community_object.numPosts + 1
                community_object.save()
                
                instance.community.numPosts = instance.community.numPosts - 1
                instance.community.save()
                
            
            
            serializer = self.get_serializer(instance, data=request.data, partial=True)
            serializer.is_valid(raise_exception=True)
            serializer.save(user_owner=user_profile.username)

            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)


    def destroy(self, request, *args, **kwargs):
        user_profile = getattr(request.user, 'profile', None)
        instance = self.get_object()
        user_owner = getattr(instance, 'user_owner', None)
        instance.community.numPosts = instance.community.numPosts - 1
        instance.community.save()

        if user_profile.username != user_owner:
            return Response({"error": "Token no autorizado"}, status=status.HTTP_401_UNAUTHORIZED)
        
        elif user_profile is not None:
            instance.delete()
            return Response({"message": "Post eliminado exitosamente"}, status=status.HTTP_204_NO_CONTENT)
        else:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)



    @action(detail=False, methods=['get'])
    def saved(self, request):
        user_profile = getattr(request.user, 'profile', None)
                    
        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
    
        else:
            saved_posts = SavedPost.objects.filter(user=user_profile.username)
            post_ids = saved_posts.values_list('post__id', flat=True)
            posts = Post.objects.filter(id__in=post_ids)
            serializer = self.get_serializer(posts, many=True)

            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
            
            
    @action(detail=True, methods=['post'], url_path='save')
    def save_post(self, request, pk=None):        
        user_profile = getattr(request.user, 'profile', None)
        instance = self.get_object()

            
        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
    
        else:
            try:   
                saved_post = SavedPost.objects.get(post=instance, user=user_profile.username)
            except Exception:
                saved_post = None

            
            if saved_post:
                return Response({"error": "El post ya está guardado"}, status=status.HTTP_400_BAD_REQUEST)

            else:
                saved_post_object = SavedPost(post=instance, user=user_profile.username)
                saved_post_object.save()
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
            
            
    @action(detail=True, methods=['post'], url_path='unsave')
    def unsave_post(self, request, pk=None):        
        user_profile = getattr(request.user, 'profile', None)
        instance = self.get_object()
        
            
        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)
    
        else:
            try:   
                saved_post = SavedPost.objects.get(post=instance, user=user_profile.username)
            except Exception:
                saved_post = None

            
            if saved_post is None:
                return Response({"error": "El post no está guardado"}, status=status.HTTP_400_BAD_REQUEST)

            else:
                saved_post.delete()
                
                serializer = self.get_serializer(instance)

                headers = self.get_success_headers(serializer.data)
                return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

        

        
    @action(detail=False, methods=['get'])
    def subscribed(self, request):
        user_profile = getattr(request.user, 'profile', None)

        if user_profile is None:
            return Response({"error": "No se encontró un perfil asociado al usuario"}, status=status.HTTP_400_BAD_REQUEST)

        else:
            posts = {}
            list_communities = Community.objects.filter(subscribers=request.user).order_by('-id')
            for post in Post.objects.all():
                for community in list_communities:
                    if post.community == community:
                            posts[post] = post
            
            serializer = self.get_serializer(posts, many=True)

            headers = self.get_success_headers(serializer.data)
            return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)
