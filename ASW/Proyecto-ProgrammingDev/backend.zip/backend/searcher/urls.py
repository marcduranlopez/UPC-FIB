from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from searcher import views

urlpatterns = [
    path("api/search/", views.searcher, name="search"),
    path("search/", views.search, name="search"),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
