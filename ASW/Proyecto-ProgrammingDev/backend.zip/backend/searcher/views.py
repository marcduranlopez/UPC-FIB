from django.shortcuts import render
from posts.models import Post
from posts.serializers import CommentSerializer
from posts.api.serializers import PostSerializer
from posts.views import applyCommunitiesFilter, applySortFilter, applyDataFilter, getCommunityFilter, getDataFilter, getSortFilter, getSavedPosts, paginate
from communities.models import Community
from users.models import Profile
from django.db.models import Q
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from rest_framework.decorators import authentication_classes, permission_classes

community_filters = ['local','subscribed']
dataType_filters = ['publicaciones', 'comentarios']
sort_filters = ['new', 'old', 'best', 'commented']


@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def searcher(request):
    
    keywords = request.query_params.get("keywords")
    if keywords is None or keywords == "":
        return Response({}, status=status.HTTP_200_OK)
        
    author = request.query_params.get("author", "Todo")
    comm = request.query_params.get("community", "Todo")
    dataType = getDataFilter(request)
    if dataType not in dataType_filters:
        return Response({'error': 'The dataType parameter can only have this two values: publicaciones or comentarios'}, status=status.HTTP_400_BAD_REQUEST)
    filter = getCommunityFilter(request)
    if filter not in community_filters:
        return Response({'error': 'The filter parameter can only have this two values: subscribed or local'}, status=status.HTTP_400_BAD_REQUEST)
    sortType = getSortFilter(request)
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    stuff = applyDataFilter(dataType)
    stuff = applyCommunitiesFilter(dataType, filter, request.user, stuff)
        
    if author != "Todo":
        try:
            profile = Profile.objects.get(id=author)
        except Profile.DoesNotExist:
            return Response({'error': 'Author does not exist'}, status=status.HTTP_404_NOT_FOUND)
        stuff = stuff.filter(user_owner=profile.username)
        
    if dataType == "publicaciones":
        stuff = stuff.filter(Q(title__icontains=keywords) | Q(description__icontains=keywords))
            
        if comm != "Todo":
            try:
                community = Community.objects.get(id=comm)
            except Community.DoesNotExist:
                return Response({'error': 'Community does not exist'}, status=status.HTTP_404_NOT_FOUND)
            stuff = stuff.filter(community=community)
        stuff = applySortFilter(dataType, sortType, stuff)
        stuff = paginate(stuff, request)
        serializer = PostSerializer(stuff, many=True)
            
    else:
        stuff = stuff.filter(body__icontains=keywords)
            
        if comm != "Todo":
            try:
                community = Community.objects.get(id=comm)
            except Community.DoesNotExist:
                return Response({'error': 'Community does not exist'}, status=status.HTTP_404_NOT_FOUND)
            posts = Post.objects.filter(community=community)
            stuff = stuff.filter(post__in=posts)
        stuff = applySortFilter(dataType, sortType, stuff)
        stuff = paginate(stuff, request)
        serializer = CommentSerializer(stuff, many=True)
    
    return Response(serializer.data, status=status.HTTP_200_OK)

def search(request):
    
    communities = Community.objects.all()
    profiles = Profile.objects.exclude(username='admin')
    saved_posts = getSavedPosts(request.user)
    context = { 'communities': communities, 'profiles': profiles, 'saved_posts': saved_posts }
    keywords = request.GET.get("keyword/s")
    if not keywords is None:
        
        author = request.GET.get("author", "Todo")
        comm = request.GET.get("community", "Todo")
        dataType = getDataFilter(request)
        filter = getCommunityFilter(request)
        sortType = getSortFilter(request)
        
        stuff = applyDataFilter(dataType)
        stuff = applyCommunitiesFilter(dataType, filter, request.user, stuff)
        
        if author != "Todo":
            profile = Profile.objects.get(id=author)
            stuff = stuff.filter(user_owner=profile.username)
        
        if dataType == "publicaciones":
            stuff = stuff.filter(Q(title__icontains=keywords) | Q(description__icontains=keywords))
            
            if comm != "Todo":
                community = Community.objects.get(id=comm)
                stuff = stuff.filter(community=community)
            stuff = applySortFilter(dataType, sortType, stuff)
            context['posts'] = stuff
            
        else:
            stuff = stuff.filter(body__icontains=keywords)
            
            if comm != "Todo":
                community = Community.objects.get(id=comm)
                posts = Post.objects.filter(community=community)
                stuff = stuff.filter(post__in=posts)
            stuff = applySortFilter(dataType, sortType, stuff)
            context['comments'] = stuff
        
    return render(request, 'searcher/buscador.html', context)
    

