from django import forms
from .models import Profile
from django.core.exceptions import ValidationError

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['nom', 'biografia', 'banner', 'avatar']
        
    def clean_biografia(self):
        biografia = self.cleaned_data.get('biografia')
        if len(biografia) > 250:
            raise forms.ValidationError("La biografía no puede exceder los 250 caracteres.")
        return biografia
    
    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)
        self.fields['nom'].widget.attrs['class'] = 'form-control'
        self.fields['biografia'].widget.attrs['class'] = 'form-control'
        self.fields['biografia'].widget.attrs['rows'] = '3'

    error_messages = {
        'nom': {
            'required': "El nombre no puede estar vacío.",
        },
        'biografia': {
            'max_length': "La biografía no puede exceder los 250 caracteres.",
        },
    }