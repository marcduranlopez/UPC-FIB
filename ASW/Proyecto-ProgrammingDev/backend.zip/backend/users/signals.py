# En tu archivo signals.py en tu aplicación principal (puede necesitar crearlo)
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from users.models import Profile
from rest_framework.authtoken.models import Token

@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        # Si el usuario es nuevo, creamos un UserProfile con los datos iniciales
        print("creado")
        Profile.objects.create(
            user=instance,
            username=instance.username,
            token = Token.objects.create(user=instance).key,
            nom=f"{instance.first_name} {instance.last_name}"
        )
    else:
        print("ya estaba")
        # Si el usuario ya existe, comprobamos si el username ha cambiado
        try:
            existing_user = User.objects.get(pk=instance.pk)
            if existing_user.username != instance.username:
                # Si el username ha cambiado, actualizamos UserProfile
                user_profile = Profile.objects.get_or_create(user=instance)
                user_profile.username = instance.username
                user_profile.save()
        except User.DoesNotExist:
            pass
