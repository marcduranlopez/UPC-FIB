from django.urls import reverse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from .models import Profile
from .forms import ProfileForm
from posts.models import Post, Comment
from posts.serializers import CommentSerializer
from posts.api.serializers import PostSerializer
from users.serializers import ProfileSerializer, ProfileShortSerializer
from posts.views import getSavedPosts, getSortFilter, applySortFilter, getDataFilter, applyDataFilter, getSavedComments, paginate
from posts.views import get_saved_posts_for_blog, posts_by_order_type, order_by_filters
from rest_framework import status, viewsets
from rest_framework.decorators import action, authentication_classes, permission_classes, api_view
from rest_framework.authtoken.models import Token
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.pagination import PageNumberPagination
from rest_framework import filters
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticatedOrReadOnly, IsAuthenticated
from rest_framework.parsers import MultiPartParser

sort_filters = ['new', 'old', 'best', 'commented']

class ProfileView(viewsets.ModelViewSet):
    queryset = Profile.objects.all()
    permission_classes = [IsAuthenticatedOrReadOnly] 
    authentication_classes = [TokenAuthentication]
    pagination_class = PageNumberPagination
    pagination_class.page_size = 10
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    parser_classes = [MultiPartParser]

    ordering_fields = ['id']

    filterset_fields = ['username']

    def get_serializer_class(self):
        if self.action == 'list':
            return ProfileShortSerializer
        return ProfileSerializer


    @action(methods=['PUT'], detail=True)
    def update_profile(self, request, pk=None):
        profile = self.get_object()
        
        newNom = request.data.get('nom', profile.nom)
        newBanner = request.FILES['banner']
        newAvatar = request.FILES['avatar']
        newBiografia = request.data.get('biografia', None)

        if request.user.id != int(pk):
            return Response({'detail': 'No tens permisos per fer aquesta acció'}, status=status.HTTP_403_FORBIDDEN)

        if newNom is not None:
            profile.nom = newNom

        if newBanner is not None:
            profile.banner = newBanner
            Profile.upload_image(newBanner, newBanner.name)
        
        if newAvatar is not None:
            profile.avatar = newAvatar
            Profile.upload_image(newAvatar, newAvatar.name)

        if newBiografia is not None:
            profile.biografia = newBiografia
        
        profile.save()

        serializer = ProfileSerializer(profile)
        return Response({'data': serializer.data, 'message': "S'ha actualitzat el perfil"}, status=status.HTTP_200_OK)

@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_user_comments(request, user_id):
    
    try:
        profile = Profile.objects.get(id=user_id)
    except Profile.DoesNotExist:
        return Response({'error': 'Profile does not exist'}, status=status.HTTP_404_NOT_FOUND)
     
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    comments = Comment.objects.filter(user_owner=profile.username)
    comments = applySortFilter("comentarios", sortType, comments)
    
    comments = paginate(comments, request)
    serializer = CommentSerializer(comments, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_user_posts(request, user_id):
    
    try:
        profile = Profile.objects.get(id=user_id)
    except Profile.DoesNotExist:
        return Response({'error': 'Profile does not exist'}, status=status.HTTP_404_NOT_FOUND)
     
    sortType = request.query_params.get('sortType', 'new')
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    posts_made = Post.objects.filter(user_owner=profile.username)
    posts_made = applySortFilter("posts", sortType, posts_made)
    
    posts_made = paginate(posts_made, request)
    serializer = PostSerializer(posts_made, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

    
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticatedOrReadOnly])
@api_view(['GET'])
def get_user_saved_comments(request, user_id):
    
    try:
        profile = Profile.objects.get(id=user_id)
    except Profile.DoesNotExist:
        return Response({'error': 'Profile does not exist'}, status=status.HTTP_404_NOT_FOUND)
    
    sortType = getSortFilter(request)
    if sortType not in sort_filters:
        return Response({'error': 'The sortType parameter can only have this four values: new, old, best or commented'}, status=status.HTTP_400_BAD_REQUEST)
    
    saved_comments = getSavedComments(profile.user)
    comment_ids = [comment.id for comment in saved_comments]
    saved_comments = Comment.objects.filter(id__in=comment_ids)
    saved_comments = applySortFilter("comentarios", sortType, saved_comments)
    saved_comments = paginate(saved_comments, request)
    serializer = CommentSerializer(saved_comments, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['POST'])
def signup_profile(request):
    serializer = ProfileSerializer(data=request.data)
    email = request.data.get('email')
    if Profile.objects.filter(email=email).exists():
        return Response({'email: This email is already used'}, status=status.HTTP_400_BAD_REQUEST)
    if serializer.is_valid():
        serializer.save()
        user = Profile.objects.get(username=request.data['username'])
        user.set_password(request.data['password'])
        user.save()
        token = Token.objects.create(user=user)
        return Response({'token': token.key, 'user': serializer.data})
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def login_view(request):
    return render(request, "loginGoogle.html")

def logout_view(request):
    logout(request)
    return redirect("/")

def view_profile(request):
    id = request.user.id
    return redirect(reverse('show_profile', args=[id]))

def show_profile(request, id):
    
    profile = get_object_or_404(Profile, user_id=id)
    dataType = getDataFilter(request)
    sortType = getSortFilter(request)
    stuff = applyDataFilter(dataType)
    
    stuff = stuff.filter(user_owner=profile.username)
    stuff = applySortFilter(dataType, sortType, stuff)
    
    context = {
        'profile': profile,
        'type': 'users'
    }
    
    if dataType == "publicaciones":
        saved_posts = getSavedPosts(request.user)
        context['saved_posts'] = saved_posts
        context['posts'] = stuff
    else:
        context['comments'] = stuff
    
    return render(request, 'profile.html', context)

@login_required
def view_user_saved_stuff(request, id):
    # Recupera el objeto de perfil de usuario usando el ID proporcionado en la URL
    profile = get_object_or_404(Profile, user_id=id)
    dataType = getDataFilter(request)
    sortType = getSortFilter(request)
    
    if dataType == "publicaciones":
        saved_posts = getSavedPosts(profile.user)
        post_ids = [post.id for post in saved_posts]
        saved_posts = Post.objects.filter(id__in=post_ids)
        saved_posts = applySortFilter(dataType, sortType, saved_posts)
        context = { 'posts': saved_posts, 'saved_posts': saved_posts }
    else:
        saved_comments = getSavedComments(profile.user)
        comment_ids = [comment.id for comment in saved_comments]
        saved_comments = Comment.objects.filter(id__in=comment_ids)
        saved_comments = applySortFilter(dataType, sortType, saved_comments)
        context = { 'comments': saved_comments }
    
    return render(request, 'saved_stuff.html', context)

@login_required
def edit_profile(request, id):
    profile = get_object_or_404(Profile, user_id=id)

    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('view_user', id=profile.user_id)
    else:
        form = ProfileForm(instance=profile)

    return render(request, 'edit_profile.html', {'form': form, 'profile': profile})

@login_required
def view_user_saved_posts(request, id):
    # Recupera el objeto de perfil de usuario usando el ID proporcionado en la URL
    saved_posts = get_saved_posts_for_blog(request.user.username)
    context = {
        'posts': saved_posts,
        'saved_posts': saved_posts,
    }
    # Renderiza la plantilla y pasa el perfil como contexto
    return render(request, 'saved_posts.html', context)

def order_posts_comments(request, id):
    profile = get_object_or_404(Profile, user_id=id)
        
    type = request.GET.get("sort_type")
    filter_condition = {"user_owner": profile.username}
    posts = posts_by_order_type(type=type, filter_condition=filter_condition) 
    saved_posts = get_saved_posts_for_blog(profile.username)
    context = {
        'profile': profile,
        'posts': posts,
        'saved_posts': saved_posts,
    }

    return render(request, 'profile.html', context)
