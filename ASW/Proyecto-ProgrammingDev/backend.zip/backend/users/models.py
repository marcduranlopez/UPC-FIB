from django.contrib.auth.models import User
from django.db import models
from rest_framework.authtoken.models import Token
from storages.backends.gcloud import GoogleCloudStorage
storage = GoogleCloudStorage()

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    username = models.CharField(max_length=100, blank=False,)
    nom = models.CharField(max_length=100, blank=False)
    biografia = models.TextField(max_length=250, default='', blank=True)
    banner = models.ImageField(upload_to='banners/', null=True, blank=True)
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    data_alta = models.DateTimeField(auto_now_add=True)
    num_publicacions = models.IntegerField(default=0)
    num_comentaris = models.IntegerField(default=0)
    token = models.CharField(max_length=40, blank=True, null=True, unique=True)

    class Meta:
        verbose_name = 'Profile'
        verbose_name_plural = 'Profiles'

    def save(self, *args, **kwargs):
        # Si no hay un token asignado, crea uno y asígnalo
        if not self.token:
            self.token = Token.objects.create(user=self.user).key
        super(Profile, self).save(*args, **kwargs)

    @property
    def user_info(self):
        user_associated = self.user
        if user_associated:
            return [
                {'id': user_associated.id, 'nom': f"{user_associated.first_name} {user_associated.last_name}" , 'email': user_associated.email}
            ]
        return None
    
    @staticmethod
    def upload_image(file, filename):
        try:
            target_path = '/images/' + filename
            path = storage.save(target_path, file)
            return storage.url(path)
        except Exception as e:
            print("Failed to upload!")