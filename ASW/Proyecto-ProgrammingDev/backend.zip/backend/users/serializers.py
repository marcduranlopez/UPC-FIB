from rest_framework import serializers
from .models import Profile

class ProfileShortSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ('id', 'username', 'nom', 'biografia', 'banner', 'avatar', 'data_alta', 'num_publicacions','num_comentaris')

class ProfileSerializer(serializers.ModelSerializer):
    user_info = serializers.SerializerMethodField()

    class Meta(object):
            model = Profile
            fields = ('id', 'user_info', 'username', 'nom', 'biografia', 'banner', 'avatar', 'data_alta', 'num_publicacions','num_comentaris')
            
    def get_user_info(self, obj):
        return obj.user_info