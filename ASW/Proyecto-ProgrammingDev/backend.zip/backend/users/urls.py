from django.urls import path, re_path, include
from . import views
from rest_framework import routers
from .views import ProfileView

router = routers.DefaultRouter()
router.register(prefix='users', basename='users', viewset=ProfileView)

urlpatterns = [
    path("api/users/<user_id>/comments/", views.get_user_comments, name="get_user_comments"),
    path("api/users/<user_id>/savedComments/", views.get_user_saved_comments, name="get_user_saved_comments"),
    path("users/login/", views.login_view, name="login_view"),
    path("users/logout/", views.logout_view, name="logout_view"),
    path('users/view/', views.view_profile, name='view_profile'),
    path('users/<int:id>/', views.show_profile, name='show_profile'),
    path('api/users/<int:pk>/edit/', ProfileView.as_view({'put': 'update_profile'}), name='update_profile'),
    path('users/<int:id>/edit/', views.edit_profile, name='edit_profile'),
    path('users/<int:id>/sort_type/', views.order_posts_comments, name='order_posts_comments'),
    path('users/<int:id>/saved_posts/', views.view_user_saved_stuff, name='view_user_saved_stuff'),
    path("api/users/<user_id>/posts/", views.get_user_posts, name="get_user_posts"),
    path("api/", include(router.urls)),
]
