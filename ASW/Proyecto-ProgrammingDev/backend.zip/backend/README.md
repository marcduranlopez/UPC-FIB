Membres:
Emanuel Peña
Marc Duran
Xavi Martí
Yasser El Mansouri	


Taiga:
https://tree.taiga.io/project/xavimll02-asw/timeline


Aplicació desplegada:
https://asw-proj.fly.dev/
