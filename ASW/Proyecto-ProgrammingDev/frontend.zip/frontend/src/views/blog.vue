<template>
  <v-container class="my-4 mx-4">
    <h1 style="color: #000000" class="my-5 ml-5">Listado de publicaciones y comentarios</h1>
    <v-row no-gutters style="max-width: 900px; max-height: 120px">
      <v-col>
        <DataType @dataTypeEvent="handleDataTypeEvent"/>
      </v-col>
      <v-col>
        <ListingType @listingTypeEvent="handleListingTypeEvent"/>
      </v-col>
      <v-col>
        <Sorting @sortingEvent="handleSortingEvent"/>
      </v-col>
      <v-spacer></v-spacer>
    </v-row>
    <listOfItems :items="data" :typeOfList="dataType" @commentEvent="handleCommentEvent"/>
    <v-row no-gutters>
      <Pagination :page="page" @paginationEvent="handlePaginationEvent"/>
    </v-row>
  </v-container>
</template>

<script setup>
  import DataType from '@/components/DataType.vue';
  import ListingType from '@/components/ListingType.vue';
  import Pagination from '@/components/Pagination.vue';
  import Sorting from '@/components/Sorting.vue';
  import listOfItems from '@/components/listOfItems.vue';
  import axios from "axios";
</script>

<script>
  export default {
    data() {
      return {
        data: [],
        dataType: 'posts',
        sortType: 'new',
        page: 1,
        listingType: 'local',
      };
    },
    mounted() {
      this.getStuff("https://asw-proj.fly.dev/api/get_posts/", false);
    },
    methods: {
      handleCommentEvent() {
        this.updateContent();
      },
      handlePaginationEvent(value) {
        this.page += value;
        this.updateContent();
      },
      handleSortingEvent(sortType) {
        this.sortType = sortType;
        this.page = 1;
        this.updateContent();
      },
      handleListingTypeEvent(listingType) {
        this.listingType = listingType;
        this.page = 1;
        this.updateContent();
      },
      handleDataTypeEvent(dataType) {
        this.dataType = dataType;
        this.page = 1;
        this.updateContent();
      },
      updateContent() {

        let url = "https://asw-proj.fly.dev/api/";
        if (this.dataType == "comments") {
          url = url + "comments/";
        }
        else {
          url = url + "get_posts/";
        }
        url = url + `?communitiesType=${this.listingType}&page=${this.page}&sortType=`;
        switch (this.sortType) {
            case 'Más Comentado':
              url = url + 'commented';
              break;
            case 'Antiguo':
              url = url + 'old';
              break;
            case 'El mejor de todos los tiempos':
              url = url + 'best';
              break;
            default:
              url = url + 'new';
            break;
        }
        this.getStuff(url, this.listingType == "subscribed" ? true : false);
      },
      getStuff(url, subscribed) {

        let config = {
        }
        if (subscribed) {
          let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
          config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          }
        }
        axios.get(url, config)
          .then(response => {
              this.data = response.data;
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
      },
    },
  };
</script>
  