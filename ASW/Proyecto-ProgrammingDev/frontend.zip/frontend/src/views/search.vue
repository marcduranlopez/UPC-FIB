<template>
  <v-container class="my-4 mx-4">
    <h1 style="color: #000000" class="my-5 ml-5">Buscador de publicaciones y comentarios</h1>
    <v-row no-gutters style="max-width: 1450px;" align="center">
      <v-col>
        <DataType @dataTypeEvent="handleDataTypeEvent"/>
      </v-col>
      <v-col>
        <ListingType @listingTypeEvent="handleListingTypeEvent"/>
      </v-col>
      <v-col>
        <Sorting class="mt-4" @sortingEvent="handleSortingEvent"/>
      </v-col>
      <v-col>
        <CommunitySelector class="mt-4" @communityEvent="handleCommunityEvent"/>
      </v-col>
      <v-col>
        <AuthorSelector class="mt-4" @authorEvent="handleAuthorEvent"/>
      </v-col>
      <v-col cols="3" class="mt-4">
      <v-text-field
        v-model="keywords"
        label="Introduce tus palabras clave"
        class="ml-4"
      ></v-text-field>
      </v-col>
      <v-btn class="ml-4" @click="search">Buscar</v-btn>
      <v-spacer></v-spacer>
    </v-row>
    <listOfItems :items="data" :typeOfList="dataType" @commentEvent="handleCommentEvent"/>
    <v-row no-gutters>
      <Pagination :page="page" @paginationEvent="handlePaginationEvent"/>
    </v-row>
  </v-container>
</template>

<script setup>
  import DataType from '@/components/DataType.vue';
  import ListingType from '@/components/ListingType.vue';
  import Pagination from '@/components/Pagination.vue';
  import Sorting from '@/components/Sorting.vue';
  import listOfItems from '@/components/listOfItems.vue';
  import AuthorSelector from '@/components/AuthorSelector.vue';
  import CommunitySelector from '@/components/CommunitySelector.vue';
  import axios from "axios";
</script>

<script>
  export default {
    data() {
      return {
        data: [],
        dataType: 'posts',
        sortType: 'new',
        page: 1,
        listingType: 'local',
        autor: 'Todo',
        comunidad: 'Todo',
        keywords: null,
      };
    },
    methods: {
      handleCommunityEvent(community) {
        this.comunidad = community;
        this.page = 1;
        this.search();
      },
      handleAuthorEvent(author) {
        this.autor = author;
        this.page = 1;
        this.search();
      },
      handleCommentEvent() {
        this.search();
      },
      handlePaginationEvent(value) {
        this.page += value;
        this.search();
      },
      handleSortingEvent(sortType) {
        this.sortType = sortType;
        this.page = 1;
        this.search();
      },
      handleListingTypeEvent(listingType) {
        this.listingType = listingType;
        this.page = 1;
        this.search();
      },
      handleDataTypeEvent(dataType) {
        this.dataType = dataType;
        this.page = 1;
        this.search();
      },
      search() {

        let url = "https://asw-proj.fly.dev/api/search/?";
        if (this.dataType == "comments") {
          url = url + "dataType=comentarios&";
        }
        else {
          url = url + "dataType=publicaciones&";
        }
        url = url + `filter=${this.listingType}&page=${this.page}&order=`;
        switch (this.sortType) {
            case 'Más Comentado':
              url = url + 'commented';
              break;
            case 'Antiguo':
              url = url + 'old';
              break;
            case 'El mejor de todos los tiempos':
              url = url + 'best';
              break;
            default:
              url = url + 'new';
            break;
        }
        url = url + `&keywords=${this.keywords}&author=${this.autor}&community=${this.comunidad}`;
        this.getStuff(url, this.listingType == "subscribed" ? true : false);
      },
      getStuff(url, subscribed) {

        let config = {
        }
        if (subscribed) {
          let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
          config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          }
        }
        axios.get(url, config)
          .then(response => {
              if (Array.isArray(response.data)) this.data = response.data;
              else this.data = [];
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
      },
    },
  };
</script>
  