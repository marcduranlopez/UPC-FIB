<template>
  <postFormPreview :item="item" :typeOfForm="create"/>
</template>



<script setup>
import postFormPreview from '@/components/postFormPreview.vue';
</script>

<script>
  export default {
    data() {
      return {
        item: null,
        create: "create",
      }
    }
  }
</script>