<template>
  <v-col>
    <h1 style="color: #000000" class="my-5 ml-5">Perfil</h1>
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12">
        <!-- ========================== AVATAR Y SETTINGS ========================== -->
        <v-card :loading="loading">
          <div class="mb-3">
            <div style="height:200px;">
              <div class="banner-img">
                <v-img :src="profile.banner" cover class="center-image"></v-img>
              </div>
              <div class="position-absolute">
                <v-avatar v-if="profile.avatar !== null" :image="profile.avatar" size="150"
                  style="bottom:50px; left: 20px;"></v-avatar>
              </div>
            </div>
          </div>
          <v-card-text v-if="loading == true">Loading...</v-card-text>
          <v-card-text v-else>
            <!-- ============================= SLOTS V-CARD ============================== -->
            <v-row class="mx-6 align-center">
              <v-card-title style="margin-left:150px">{{ profile.nom }}</v-card-title>
              <v-col class="text-right">
                <v-btn v-if="user.id == userId" variant="text" icon="mdi-pencil"
                  @click="handleIconClick('/users/' + userId + '/edit')"></v-btn>
              </v-col>
            </v-row>
            <v-col class="mt-4">
              <v-card-text class="mx-auto mt-5">{{
                profile.biografia
              }}</v-card-text>
            </v-col>
            <v-row class="mt-4 ml-4 justify-space-between" justify="space-between">
              <v-card-text class="mt-5 text-center"><v-icon class="mr-2">mdi-text</v-icon>
                <strong>{{ profile.num_publicacions }}</strong></v-card-text>
              <v-card-text class="mt-5 text-center"><v-icon class="mr-2">mdi-comment-multiple</v-icon>
                <strong>{{ profile.num_comentaris }}</strong></v-card-text>
              <v-card-text class="mt-5 text-center"><v-icon class="mr-2">mdi-calendar-clock</v-icon>
                <strong>{{
                  new Date(profile.data_alta).toLocaleDateString("es-ES")
                }}</strong></v-card-text>
            </v-row>
            <v-col class="mt-15 mb-4">
              <v-card>
                <v-tabs v-model="tab" bg-color="#000000" fixed-tabs>
                  <v-tab v-for="i in madeByUser.length" :key="i" :value="i">
                    {{ madeByUser[i - 1].title }}
                  </v-tab>
                  <v-btn v-if="userIsLoggedIn" :icon="showSaved ? 'mdi-bookmark' : 'mdi-bookmark-outline'" variant="plain" class="position-relative ml-auto mr-4" :loading="loadingSaved"
                    @click="showSavedStuff">
                  </v-btn>
                </v-tabs>
                <div class="content-container">
                  <v-window v-model="tab">
                    <!-- :value sincroniza con las tabs -->
                    <v-window-item v-for="n in madeByUser.length" :key="n" :value="n">
                      <ListOfItems :items="madeByUser[n - 1].arr" :typeOfList="madeByUser[n - 1].typeof" />
                    </v-window-item>
                  </v-window>
                </div>
              </v-card>
            </v-col>
          </v-card-text>
        </v-card>
      </v-col>
    </v-container>
  </v-col>
</template>

<!-- =============================== SCRIPTS =============================== -->
<script setup>
import axios from "axios";
import { mapGetters } from "vuex";
import ListOfItems from "@/components/listOfItems.vue";
</script>

<script>
export default {
  data() {
    return {
      profile: {},
      userId: null,
      loading: false,
      tab: null,
      madeByUser: [
        {
          title: "Publicacions",
          typeof: "posts",
          arr: [],
        },
        {
          title: "Comentaris",
          typeof: "comments",
          arr: [],
        },
      ],
      showSaved: false,
      loadingSaved: false,
      userIsLoggedIn: false,
    };
  },
  components: {
    ListOfItems,
  },
  created() {
    this.loading = true;
    this.userId = this.$route.params.user_id;
    this.userIsLoggedIn = this.user.id == this.userId ? true : false;
  },
  mounted() {
    this.getPosts();
    this.getComments();
    this.getUserInfo();
  },
  methods: {
    handleIconClick(route) {
      this.$router.push(route);
    },
    getUserInfo() {
      const token = this.$store.getters.getTokenById(this.userId);
      axios
        .get(`https://asw-proj.fly.dev/api/users/${this.userId}/`, {
          headers: {
            Authorization: `Token ${token}`,
            "Content-Type": "application/json",
          },
        })
        .then((response) => {
          this.profile = response.data;
          this.$store.commit("setProfileData", this.profile);
          this.loading = false;
        })
        .catch((error) => {
          // Maneja errores aquí
          console.error("Error al obtener los datos del usuario:", error);
        });
    },
    getPosts() {
      let urlToFetch = "";
      if (this.showSaved) urlToFetch = "/posts/saved/";
      else urlToFetch = "/users/" + this.userId + "/posts/";
      const requestOptions = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Token ${this.user.token}`,
        }
      };
        fetch("https://asw-proj.fly.dev/api" + urlToFetch, requestOptions)
          .then((response) => {
            if (!response.ok) {
              throw new Error(
                `Error al obtener los usuarios: ${response.status}`
              );
            }
            return response.json();
          })
          .then((data) => {
            this.madeByUser[0].arr = data;
          })
          .catch((error) => {
            console.error(error);
          });
    },
    getComments() {
  
      let urlToFetch = "";
      if (this.showSaved) urlToFetch = "/users/" + this.userId + "/savedComments/";
      else urlToFetch = "/users/" + this.userId + "/comments/";
      const requestOptions = {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Token ${this.user.token}`,
        }
      };
      fetch("https://asw-proj.fly.dev/api" + urlToFetch, requestOptions)
        .then((response) => {
          if (!response.ok) {
            throw new Error(`Error al obtener los eventos: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          this.madeByUser[1].arr = data;
          this.loadingSaved = false;
        })
        .catch((error) => {
          console.error(error);
        });
    },
    showSavedStuff() {
      this.loadingSaved = true;
      this.showSaved = !this.showSaved;
      this.getPosts();
      this.getComments();
    },
  },
  computed: {
    ...mapGetters(['user']),
  },
};
</script>

<!-- =============================== ESTILOS =============================== -->
