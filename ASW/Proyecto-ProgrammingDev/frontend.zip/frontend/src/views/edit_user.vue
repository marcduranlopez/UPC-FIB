<!-- ======================================================================= -->
<!--                           VISTA EDITAR PERFIL                           -->
<!-- ======================================================================= -->

<template>
  <v-col>
    <!-- =============================== TITULO ================================ -->
    <h1 class="my-5 ml-5">Editar Perfil</h1>
    <!-- ============================== CONTENIDO ============================== -->
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12" md="10" sm="8">
        <v-card class="pa-12" variant="elevated">
          <v-form @submit.prevent="submit" enctype="multipart/form-data">
            <!-- ======================= EDITAR AVATAR/BANNER ======================= -->
            <div style="height: 200px; margin-bottom: 100px;">
              <profileImg :img="formData.avatar" @update-img="updateAvatar" type="avatar" />
              <profileImg :banner="formData.banner" @update-banner="updateBanner"  type="banner" />
            </div>
            <!-- ============================= TEXTFIELDS ============================== -->
            <v-row class="mt-16">
              <v-col cols="12" md="6" sm="12">
                <v-text-field cols="6" label="Username" v-model="formData.username" variant="filled"
                  readonly></v-text-field>
              </v-col>
              <v-col cols="6" md="6" sm="12">
                <v-text-field cols="6" label="Name" v-model="formData.nom" variant="outlined"></v-text-field>
              </v-col>
            </v-row>
            <v-row justify="center">
              <v-col class="ma-1">
                <v-textarea label="Biography" v-model="formData.biografia" variant="outlined"></v-textarea>
              </v-col>
            </v-row>

            <!-- ============================= SUBMITFORM ============================== -->
            <v-row justify="center">
              <v-col cols="4" sm="8">
                <v-btn :loading="loading" type="submit" block class="mt-2" :color="loading ? 'success' : '#000000'"
                  append-icon="mdi-check-circle-outline">
                  {{ loading ? '<v-icon>mdi-check-circle</v-icon>' : 'Confirmar cambios' }}
                </v-btn>
              </v-col>
            </v-row>
          </v-form>
        </v-card>
      </v-col>
    </v-container>
  </v-col>

</template>

<!-- =============================== SCRIPTS =============================== -->

<script>
import profileImg from "@/components/profileImg.vue";
import axios from "axios";

export default {
  data() {
    return {
      formData: { ...this.$store.state.profileData },
      avatar: this.$store.state.profileData.avatar,
      banner: this.$store.state.profileData.banner,
      isEditing: false,
      loading: false,
      timeout: null,
      userId: null,
      appState: null,
    };
  },
  methods: {
    async submit() {
      this.loading = true;
      try {
        const token = this.$store.getters.getTokenById(this.userId);
        const ruta = "https://asw-proj.fly.dev/api/users/" + this.userId + "/";
        const formData = new FormData();
        if (this.avatar instanceof File) {
          formData.append('avatar', this.avatar);
        }
        if (this.banner instanceof File) {
          formData.append('banner', this.banner);;
        }
        formData.append('nom', this.formData.nom);
        formData.append('biografia', this.formData.biografia);
        formData.append('username', this.formData.username)
        await axios.put(ruta, formData, {
          headers: {
            "Authorization": `Token ${token}`,
            "Content-Type": "multipart/form-data",
          },
        });
        this.$store.commit('setProfileData', this.formData);
        this.$store.commit('setUserImg', this.formData.avatar);
        this.$router.push("/users/" + this.userId);
      } catch (error) {
        console.error("Error al enviar datos:", error);
      } finally {
        this.loading = false;
      }
    },
    updateAvatar(file) {
        this.formData.avatar = URL.createObjectURL(file);
        this.avatar = file;
    },
    updateBanner(file) {
        this.formData.banner = URL.createObjectURL(file);
        this.banner = file;
    },
  },
  components: {
    profileImg,
  },
  created() {
    // Acceder al ID del usuario desde los parámetros de la ruta
    this.userId = this.$route.params.user_id;
  },
};
</script>

<!-- =============================== ESTILOS =============================== -->

<style scoped>
.content-container {
  margin: 30px 0;
  /* Agrega espacio superior y inferior*/
  text-align: center;
}
</style>
