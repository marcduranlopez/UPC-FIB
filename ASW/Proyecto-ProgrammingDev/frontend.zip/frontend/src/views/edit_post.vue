<template>
  <postFormPreview :item="item" :typeOfForm="edit"/>
</template>



<script setup>
import axios from "axios";
import postFormPreview from '@/components/postFormPreview.vue';
</script>

<script>
  export default {
    data() {
      return {
        item: null,
        edit: "edit",
        postId: null,
      }
    },
  created() {
    this.postId = this.$route.params.post_id;
  },
  mounted() {
    this.getPostInfo();
  },
  methods: {
      getPostInfo() {
        
        axios
          .get(
            `https://asw-proj.fly.dev/api/posts/${this.postId}/`,
            {},
            {
              "Content-Type": "application/json",
            }
          )
          .then((response) => {
            this.item = response.data;
            console.log(this.item);
          })
          .catch((error) => {
            console.error("Error al obtener los datos del post:", error);
          });
      },
    }
  } 

</script>