<template>
  <v-col>
    <h1 style="color: #000000" class="my-5 ml-5">Crear Comunidad</h1>
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12">
        <v-card :loading="loading">
          <v-card-text v-if="loading == true">Loading...</v-card-text>
          <v-card-text v-else>
            <v-form ref="form" @submit.prevent="createCommunity">
              <v-row>
                <v-col>
                  <v-text-field v-model="community.id" label="ID" required></v-text-field>
                </v-col>
                <v-col>
                  <v-text-field v-model="community.name" label="Nombre"></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col>
                <v-file-input @change="handleBannerChange" label="Banner"></v-file-input>
              </v-col>
              <v-col>
                <v-file-input @change="handleAvatarChange" label="Avatar"></v-file-input>
              </v-col>
              </v-row>
            </v-form>
          </v-card-text>
        </v-card>
      </v-col>
    </v-container>
    <!-- ============================= BOTÓN CREAR COMUNIDAD ============================== -->
    <v-row class="mt-1 mx-16">
        <v-btn @click="createCommunity">Crear Comunidad</v-btn>
    </v-row>
  </v-col>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      loading: false,
      community: {
        id: '',
        name: '',
        banner: null,
        avatar: null,
      },
    };
  },

  methods: {

    handleBannerChange(event) {
      const file = event.target.files[0];
      this.community.banner = file;
    },

   handleAvatarChange(event) {
    const file = event.target.files[0];
    this.community.avatar = file;
    },

    createCommunity() {
    this.loading = true;

    let token = this.$store.getters.getTokenById(this.$store.getters.user.id);

    const formData = new FormData();
    formData.append('id', this.community.id);
    formData.append('name', this.community.name);
    formData.append('banner', this.community.banner);
    formData.append('avatar', this.community.avatar);

    axios
      .post('https://asw-proj.fly.dev/api/communities/', formData, {
        headers: {
          'Authorization': `Token ${token}`,
          'Content-Type': 'multipart/form-data',
        },
      })
      .then((response) => {
        console.log(response.data);
        this.$router.push('/communities');
      })
      .catch((error) => {
        console.error('Error al crear la comunidad:', error);
      })
      .finally(() => {
        this.loading = false;
      });
  },
},
};
</script>

<style scoped>
  
</style>