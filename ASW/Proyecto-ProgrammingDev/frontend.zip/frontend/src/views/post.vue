
<template>
  <v-col>
     <h1 style="color: #000000" class="my-5 ml-5">Post</h1>
     <v-container class="d-flex justify-center align-center">
       <v-col cols="12">
         <!-- ========================== AVATAR Y SETTINGS ========================== -->
         <v-card :loading="loading">
           <v-card-text v-if="loading == true">Loading...</v-card-text>
           <v-card-text v-else>
           <postPreview :item="post" />
           <v-card class="mt-4">
              <v-card-text>
                <v-text-field
                  v-model="replyText"
                  label="Escribe tu comentario"
                ></v-text-field>
              </v-card-text>
              <v-card-actions>
                <v-btn :loading="publishing" @click="publicarComentario">Publicar</v-btn>
              </v-card-actions>
            </v-card>
             <v-col class="mt-15 mb-4">
               <v-card>
                 <v-tabs v-model="tab" bg-color="#000000" fixed-tabs>
                   <v-tab >
                     {{ comments.title }}
                   </v-tab>
                 </v-tabs>
                 <div class="content-container">
                   <v-window v-model="tab">
                     <!-- :value sincroniza con las tabs -->
                     <v-window-item>
                      <Sorting @sortingEvent="handleSortingEvent"/>
                     <ListOfItemsIndented
                         :items="comments.arr"
                         :typeOfList="comments.typeof"
                         @commentEvent="handleCommentEvent"
                       />
                     </v-window-item>
                   </v-window>
                 </div>
               </v-card>
             </v-col>
           </v-card-text>
         </v-card>
       </v-col>
     </v-container>
   </v-col>
 </template>
   
   <script setup>
     import axios from "axios";
     import Sorting from "@/components/Sorting.vue";
     import ListOfItemsIndented from "@/components/listOfItemsIndented.vue";
     import postPreview from "@/components/postPreview.vue";
   </script>
 
   
 
   <script>
 export default {
   data() {
     return {
       replyText: '',
       post: {},
       sortType: 'new',
       typeof: "posts",
       postId: null,
       loading: false,
       tab: null,
       comments:
         {
           title: "Comentaris",
           typeof: "comments",
           arr: [],
         },
         publishing: false,
     };
   },
   components: {
     ListOfItemsIndented
     },
   created() {
     this.loading = true;
     this.postId = this.$route.params.post_id;
   },
   mounted() {
     this.getPostInfo(); 
     this.getComments();
   },
   methods: {
     handleSortingEvent(sortType) {
        this.sortType = sortType;
        this.getComments();
      },
     handleCommentEvent() {
        this.getComments();
      },
     handleIconClick(route) {
       this.$router.push(route);
     },
     publicarComentario() {
      this.publishing = true;
        if (this.replyText.length > 0) {
          let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
          let requestBody = {
            'body': this.replyText,
          };
          let config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          };
          axios.post(`https://asw-proj.fly.dev/api/posts/${this.postId}/comments/`, requestBody, config)
          .then(response => {
            this.getComments();
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
        }
     },
     getPostInfo() {
       axios
         .get(
           `https://asw-proj.fly.dev/api/posts/${this.postId}/`,
           {},
           {
             "Content-Type": "application/json",
           }
         )
         .then((response) => {
           this.post = response.data;
         })
         .catch((error) => {
           console.error("Error al obtener los datos del post:", error);
         });
     },
     
     getComments() {
       let url = `https://asw-proj.fly.dev/api/posts/${this.postId}/coments/?sortType=`;
       switch (this.sortType) {
          case 'Más Comentado':
            url = url + 'commented';
            break;
          case 'Antiguo':
            url = url + 'old';
            break;
          case 'El mejor de todos los tiempos':
            url = url + 'best';
            break;
          default:
            url = url + 'new';
          break;
       }
       fetch(url)
         .then((response) => {
           if (!response.ok) {
             throw new Error(`Error al obtener los comentarios: ${response.status}`);
           }
           return response.json();
         })
         .then((data) => {
             this.comments.arr = data;
             this.loading = false;
             this.publishing = false;
             this.replyText = "";
         })
         .catch((error) => {
           console.error(error);
         });
     },
   },
 };
 </script>
 
 
 
 <style scoped>
 .custom-link-color {
   color: teal; 
 }
 
 .custom-icon {
   margin-right: 2px;
 }
 
 </style>