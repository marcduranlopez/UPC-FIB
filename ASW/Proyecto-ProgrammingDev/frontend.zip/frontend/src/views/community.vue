<template>
  <v-container fluid>
    <!-- Mostrar detalles de la comunidad -->
    <v-row>
      <v-col cols="12">
        <!-- Mostrar banner, avatar, nombre e ID de la comunidad -->
        <v-card :loading="loading">

          <div class="mb-3">
            <div style="height:250px;">
              <div class="banner-img">
                <v-img :src="communityDetails.banner" cover class="center-image"></v-img>
              </div>
              <div class="position-absolute">
                <v-avatar v-if="communityDetails.avatar !== null" :image="communityDetails.avatar" size="150"
                  style="bottom:200px; left: 20px;"></v-avatar>
              </div>
            </div>
          </div>
          <v-card-text v-if="loading == true">Loading...</v-card-text>
          <v-card-text v-else>
            <div class="community-info">
              <h1 style="color: #000000; margin-bottom: 10px;">{{ communityDetails.name }}</h1>
              <div style="margin-top: 5px;">ID: {{ communityDetails.id }}</div>
            </div>

            <v-row class="community-icons-row">
              <!-- Iconos para suscripción, publicaciones, comentarios y suscriptores -->
              <div class="community-icons">
                <v-btn @click="toggleSubscription" :color="isSubscribed ? 'white' : 'red'">
                  {{ isSubscribed ? 'Desuscribirse' : 'Suscribirse' }}
                </v-btn>

                <v-icon class="mr-2 ml-3">mdi-text</v-icon>
                <div>{{ posts.length }}</div>

                <v-icon class="mr-2 ml-3">mdi-comment-multiple</v-icon>
                <div>{{ comments.length }}</div>

                <v-icon class="mr-2 ml-3">mdi-account</v-icon>
                <div>{{ communityDetails.numSubscribers }}</div>
              </div>
            </v-row>

            <v-card>
              <!-- Filtros y tipos de ordenación -->
              <v-row class="mx-6 mt-4">
                <!-- Botones para ordenar -->
                <v-btn @click="sortItems('new')" :class="{ 'order-button-selected': currentSort === 'new' }">Nuevo</v-btn>
                <v-btn @click="sortItems('old')" :class="{ 'order-button-selected': currentSort === 'old' }">Antiguo</v-btn>
                <v-btn @click="sortItems('commented')" :class="{ 'order-button-selected': currentSort === 'commented' }">Más comentado</v-btn>
                <v-btn @click="sortItems('best')" :class="{ 'order-button-selected': currentSort === 'best' }">El mejor de todos los tiempos</v-btn>
              </v-row>

              <v-row class="mx-6 mt-4">
                <v-btn @click="toggleView('posts')" :class="{ 'order-button-selected' :currentView === 'posts' }">Publicaciones</v-btn>
                <v-btn @click="toggleView('comments')" :class="{ 'order-button-selected' :currentView === 'comments' }">Comentarios</v-btn>
              </v-row>

              <!-- Listado de publicaciones o comentarios según la vista actual -->
              <list-of-items :items="getItemsToShow()" :typeOfList="currentView" />
            </v-card>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>



<script>
import axios from 'axios';
import { useRouter } from 'vue-router';
import ListOfItems from '@/components/listOfItems.vue';

export default {
  data() {
    return {
      loading: false,
      communityDetails: {},
      posts: [],
      comments: [],
      token: null,
      currentView: 'posts', // Vista predeterminada
      currentSort: 'new', // Orden predeterminado
      isSubscribed: false,
      idSelected: null, // ID del usuario actual
    };
  },
  components: {
    ListOfItems,
  },

  created() {
    this.idSelected = this.$store.getters.user.id;
    this.token = this.$store.getters.getTokenById(this.idSelected);

    const router = useRouter();
    this.communityId = router.currentRoute.value.params.community_id;
    this.fetchCommunityDetails();
  },

  methods: {
    fetchCommunityDetails() {
      console.log('Fetching community details...');
      this.loading = true;

      axios
        .get(`https://asw-proj.fly.dev/api/communities/${this.communityId}/`, {})
        .then((response) => {
          this.communityDetails = response.data.community;
          this.communityDetails.avatar = "https://imagenes.elpais.com/resizer/mNg9fHwIrExv4qHWp3en47tsm9w=/980x980/cloudfront-eu-central-1.images.arcpublishing.com/prisa/2HGX6T72D5DI7HAF5XT2SN4WOI.jpg";
          this.communityDetails.banner = "https://media.sproutsocial.com/uploads/5b_youtube-cover-photo_labels@1x-1.png";
          
          this.isSubscribed = this.communityDetails.subscribers.includes(this.idSelected);
        })
        .catch((error) => {
          console.error('Error al obtener detalles de la comunidad:', error);
        })
        .finally(() => {
          this.loading = false;
        });

      // Obtener posts desde la ruta correcta
      axios
        .get(`https://asw-proj.fly.dev/api/communities/${this.communityId}/posts`, {
          headers: {
            'Authorization': `Token ${this.token}`,
            'Content-Type': 'application/json',
          },
        })
        .then((response) => {
          this.posts = response.data;
        })
        .catch((error) => {
          console.error('Error al obtener publicaciones:', error);
        });

      // Obtener comentarios desde la ruta correcta
      axios
        .get(`https://asw-proj.fly.dev/api/communities/${this.communityId}/comments`, {
          headers: {
            'Authorization': `Token ${this.token}`,
            'Content-Type': 'application/json',
          },
        })
        .then((response) => {
          this.comments = response.data;
        })
        .catch((error) => {
          console.error('Error al obtener comentarios:', error);
        });
    },

    sortItems(sortType) {
      console.log(sortType);
      this.loading = true;
      this.currentSort = sortType;

      const apiEndpoint = this.currentView === 'posts'
        ? `https://asw-proj.fly.dev/api/communities/${this.communityId}/posts`
        : this.currentView === 'comments'
          ? `https://asw-proj.fly.dev/api/communities/${this.communityId}/comments`
          : '';

      if (apiEndpoint) {
        axios
          .get(`${apiEndpoint}?sortType=${sortType}`, {
            headers: {
              'Authorization': `Token ${this.token}`,
              'Content-Type': 'application/json',
            },
          })
          .then((response) => {
            if (this.currentView === 'posts') {
              this.posts = response.data;
            } else if (this.currentView === 'comments') {
              this.comments = response.data;
            } else {
              this.posts = this.comments = response.data;
            }
          })
          .catch((error) => {
            console.error('Error al ordenar elementos:', error);
          })
          .finally(() => {
            this.loading = false;
          });
      }
    },

    toggleView(view) {
      console.log('toggle...');
      this.currentView = view;
    },

    getItemsToShow() {
      console.log('getItems...');
      if (this.currentView === 'posts') {
        return this.posts;
      } else if (this.currentView === 'comments') {
        return this.comments;
      } else {
        return [...this.posts, ...this.comments];
      }
    },

    // Método para suscribirse o desuscribirse
    toggleSubscription() {
      this.loading = true;

      const endpoint = this.isSubscribed
        ? `https://asw-proj.fly.dev/api/communities/${this.communityId}/unsubscribe/`
        : `https://asw-proj.fly.dev/api/communities/${this.communityId}/subscribe/`;

      axios
        .post(endpoint, {}, {
          headers: {
            'Authorization': `Token ${this.token}`,
            'Content-Type': 'application/json',
          },
        })
        .then(() => {
          this.isSubscribed = !this.isSubscribed; // Actualizar el estado de la suscripción
          this.fetchCommunityDetails();
        })
        .catch((error) => {
          console.error('Error al suscribirse/desuscribirse:', error);
        })
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>

<style scoped>
.community-details-col {
  flex: 0 0 300px;
  margin-right: 40px;
}

.community-info {
  margin-top: 20px;
}

.mx-6 {
  margin-top: 20px;
  margin-bottom: 20px;
}

.order-button-selected {
  background-color: #000000;
  color: white;
}

.community-icons-row {
  position: relative; /* Cambiado a relativo para ajustarse al flujo normal del documento */
  z-index: 1; /* Asegura que la fila de iconos esté sobre los elementos de la lista */
  margin-right: 32px;
  margin-bottom: 15px;
}

.community-icons {
  display: flex;
  align-items: center;
  margin-left: auto;
}

.community-icons v-icon {
  cursor: pointer;
  margin-right: 8px;
}
</style>