<template>
  <v-col>
    <h1 style="color: #000000" class="my-5 ml-5">Lista de Comunidades</h1>
    <!-- ============================= FILTROS V-CARD ============================== -->
    <v-row class="mt-10 mx-16">
      <v-btn @click="filterCommunities('local')" :class="{ 'order-button-selected' :currentFilter === 'local' }">Mostrar Local</v-btn>
      <v-btn @click="filterCommunities('subscribed')" :class="{ 'order-button-selected' :currentFilter === 'subscribed' }">Mostrar Suscrito</v-btn>
    </v-row>
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12">
        <!-- ========================== FILTROS Y CREAR COMUNIDAD ========================== -->
        <v-card>
          <!-- Lógica de carga -->
          <v-card-text v-if="loading">Loading...</v-card-text>
          <v-card-text v-else>
            <!-- ============================= TABLA V-CARD ============================== -->
            <v-card-text>
              <v-data-table :headers="headers" :items="communities" :items-per-page="10">
                <template v-slot:item="{ item }">
                  <tr>
                    <!-- Utiliza <router-link> para crear el enlace al detalle de la comunidad -->
                    <td>
                      <router-link :to="{ name: 'community', params: { community_id: item.id } }">
                        <td>{{ item.name }}</td>
                     </router-link>
                    </td>
                    <td>{{ item.numSubscribers }}</td>
                    <td>{{ item.numPosts }}</td>
                    <td>{{ item.numComments }}</td>
                    <td>
                      <v-btn @click="toggleSubscription(item)" :color="item.isSubscribed ? 'white' : 'red'">
                        {{ item.isSubscribed ? 'Desuscribirse' : 'Suscribirse' }}
                      </v-btn>
                    </td>
                  </tr>
                </template>
              </v-data-table>
            </v-card-text>
          </v-card-text>
        </v-card>
        <!-- ============================= BOTÓN CREAR COMUNIDAD ============================== -->
        <v-row class="mt-4 mx-1">
          <v-btn @click="redirectToCreateCommunity">Crear Comunidad</v-btn>
        </v-row>
      </v-col>
    </v-container>
  </v-col>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      communities: [],
      loading: false,
      token: null,
      currentFilter: 'local',
      idSelected: null,
      isSubscribed: false,
      headers: [
        { title: 'Nombre', key: 'name' },
        { title: 'Suscriptores', key: 'numSubscribers' },
        { title: 'Publicaciones', key: 'numPosts' },
        { title: 'Comentarios', key: 'numComments' },
        { title: 'Suscribirse', key: 'suscribe' },
      ],
    };
  },

  created() {
    this.idSelected = this.$store.getters.user.id;
    this.token = this.$store.getters.getTokenById(this.idSelected);
    this.fetchCommunities();
  },

  methods: {
    fetchCommunities() {
      this.loading = true;

      const fetchPage = async (page) => {
        const url = this.currentFilter === 'subscribed'
          ? `https://asw-proj.fly.dev/api/communities/subscribed_communities/?page=${page}`
          : `https://asw-proj.fly.dev/api/communities/?page=${page}`;

        try {
          const response = await axios.get(url, {
            headers: {
              'Authorization': `Token ${this.token}`,
              'Content-Type': 'application/json',
            },
          });

          return response.data.results;
        } catch (error) {
          console.error('Error al obtener las comunidades:', error);
          return [];
        }
      };

      const getAllCommunities = async () => {
        let page = 1;
        let communities = [];
        let pageCommunities = [];

        do {
          pageCommunities = await fetchPage(page);
          communities = communities.concat(pageCommunities);
          page += 1;
        } while (pageCommunities.length === 10); // Assumes 10 items per page

        return communities;
      };

      getAllCommunities()
        .then((communities) => {
          this.communities = communities;
          this.communities.forEach((community) => {
            community.isSubscribed = community.subscribers.includes(this.idSelected);
          });
        })
        .catch((error) => {
          console.error('Error al obtener las comunidades:', error);
        })
        .finally(() => {
          this.loading = false;
        });
    },
    
    filterCommunities(filterType) {
      this.loading = true;
      this.currentFilter = filterType;

      const url = this.currentFilter === 'subscribed'
        ? 'https://asw-proj.fly.dev/api/communities/subscribed_communities/'
        : 'https://asw-proj.fly.dev/api/communities/';

      axios
        .get(url, {
          headers: {
            'Authorization': `Token ${this.token}`,
            'Content-Type': 'application/json',
          },
        })
        .then((response) => {
          if (this.currentFilter === 'subscribed') {
            this.communities = response.data.subscribed_communities;
          } else {
            this.communities = response.data.results;
          }

          this.communities.forEach((community) => {
            community.isSubscribed = community.subscribers.includes(this.idSelected);
          });
        })
        .catch((error) => {
          console.error('Error al obtener las comunidades:', error);
        })
        .finally(() => {
          this.loading = false;
        });
    },

    toggleSubscription(community) {
      this.loading = false;

      const endpoint = community.isSubscribed
        ? `https://asw-proj.fly.dev/api/communities/${community.id}/unsubscribe/`
        : `https://asw-proj.fly.dev/api/communities/${community.id}/subscribe/`;

      axios
        .post(endpoint, {}, {
          headers: {
            'Authorization': `Token ${this.token}`,
            'Content-Type': 'application/json',
          },
        })
        .then(() => {
          community.isSubscribed = !community.isSubscribed;
          this.fetchCommunities();
          // Si es necesario, actualiza el número de suscriptores y otros detalles
        })
        .catch((error) => {
          console.error('Error al suscribirse/desuscribirse:', error);
        })
        .finally(() => {
          this.loading = false;
        });
    },

    redirectToCreateCommunity() {
      this.$router.push('/create_community');
    },

  },
};
</script>

<style scoped>
.order-button-selected {
  background-color: #000000;
  color: white;
}
</style>
