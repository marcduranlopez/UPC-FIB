<template>
  <v-navigation-drawer
    expand-on-hover
    rail
    :style="{ backgroundColor: '#000000', color: '#FFFFFF' }"
  >
    <v-list style="padding: 3.5px !important">
      <div style="display: flex; align-items: center">
        <v-img
          src="../assets/logo.png"
          :min-width="48"
          :max-width="48"
          aspect-ratio="1/1"
        />
        <div style="margin-left: 1rem">The Dev's Blog</div>
      </div>
    </v-list>

    <v-divider></v-divider>

    <v-list dense nav>
      <v-list-item
        v-for="item in items"
        :key="item.title"
        :prepend-icon="item.icon"
        :title="item.title"
        :to="item.to"
        @click="handleItemClick(item.to)"
      >
      </v-list-item>
    </v-list>

    <v-divider></v-divider>

    <v-list dense nav>
      <v-list-group :value="changingAcc ? null : profile.group">
        <template v-slot:activator="{ props }">
          <v-list-item
            v-bind="props"
            :prepend-avatar="avatar"
            :title="profile.username"
            :subtitle="profile.email"
            :class="{ 'loading-item': changingAcc }"
          ></v-list-item>
        </template>

        <v-list dense nav class="v-list-item-child">
          <v-list-item
            density="compact"
            prepend-icon="mdi-account-outline"
            title="Perfil"
            @click="handleItemClick('users/' + idSelected)"
          >
          </v-list-item>
          <v-list-group>
            <template v-slot:activator="{ props }">
              <v-list-item
                v-bind="props"
                density="compact"
                prepend-icon="mdi-account-switch"
                title="Cambiar"
              >
              </v-list-item>
            </template>
            <v-list class="ml-4">
              <v-list v-model="accountSelected">
                <v-list-item
                  v-for="(item, index) in accountsList"
                  :key="index"
                  :value="index"
                  :style="{
                    display: accountSelected !== index ? 'block' : 'none',
                  }"
                  @click="selectAccount(index)"
                >
                  <v-list-item-title style="font-size: 0.8rem">{{ item.title }}</v-list-item-title>
                </v-list-item>
              </v-list>
            </v-list>
          </v-list-group>
        </v-list>
      </v-list-group>
    </v-list>
  </v-navigation-drawer>
</template>

<script setup>
import axios from "axios";
import { mapGetters, mapActions } from "vuex";
</script>

<script>
export default {
  name: "AppBar",
  data() {
    return {
      items: [
        {
          title: "Home",
          icon: "mdi-home-outline",
          to: "/",
        },
        {
          title: "Communities",
          icon: "mdi-account-group-outline",
          to: "/communities",
        },
        {
          title: "Search",
          icon: "mdi-magnify",
          to: "/search",
        },
        {
          title: "Create",
          icon: "mdi-upload",
          to: "/posts/create",
        },
      ],
      profile: {
        group: "User",
        id: null,
        username: null,
        email: null,
        avatar: null,
        children: [],
      },
      accountsList: [
        { title: "Emanuel", value: "2" },
        { title: "Yasser", value: "3" },
        { title: "Marc", value: "4" },
        { title: "Xavi", value: "5" },
      ],
      accountSelected: 0,
      idSelected: null,
      changingAcc: false,
    };
  },
  watch: {
    changingAcc(newValue) {
      if (newValue) {
        // Cierra la lista cuando changingAcc sea true
        this.profile.group = null;
      }
    },
    avatar(newAvatar) {
      // Puedes realizar acciones adicionales cuando la propiedad computada cambie, si es necesario
      this.profile.avatar = newAvatar;
    }
  },
  created() {
    if (this.user) this.accountSelected = this.user.id - 2;
    this.idSelected = this.user ? this.user.id : this.accountsList[this.accountSelected].value;
    this.getUser();
  },
  methods: {
    ...mapActions(["loginUser"]),
    handleItemClick(route) {
      window.location.pathname = route;
    },
    selectAccount(index) {
      this.changingAcc = true;
      this.accountSelected = index;
      this.idSelected = this.accountsList[this.accountSelected].value;
      this.getUser();
    },
    getUser() {
      const token = this.$store.getters.getTokenById(this.idSelected);
      axios
        .get(`https://asw-proj.fly.dev/api/users/${this.idSelected}/`, {
          headers: {
            "Authorization": `Token ${token}`,
            "Content-Type": "application/json",
          },
        })
        .then((response) => {
          this.profile.id = response.data.id;
          this.profile.username = response.data.username;
          this.profile.email = response.data.user_info.email;

          this.profile.avatar = response.data.avatar;
          
          if (!this.changingAcc) this.loginUser(response.data);
          else {
            this.$store.commit("setUser", response.data);
            if (window.location.pathname.startsWith("/users")) {
              window.location.pathname = "users/" + this.idSelected;
            }
            this.changingAcc = false;
          }
        })
        .catch((error) => {
          // Maneja errores aquí
          console.error("Error al obtener los datos del usuario:", error);
        });
    },
  },
  computed: {
    ...mapGetters(["user"]),
    avatar() {
      return this.profile.avatar;
    }
  },
};
</script>

<style scoped>
.v-list-item-child {
  padding: 0 !important;
}

.loading-item {
  opacity: 0.5;
  pointer-events: none;
}
</style>
