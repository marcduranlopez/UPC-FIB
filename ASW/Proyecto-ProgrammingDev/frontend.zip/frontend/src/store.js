// En store.js
import { createStore } from "vuex";
import createPersistedState from "vuex-persistedstate";

export default createStore({
  state: {
    user: null,
    profileData: {},
    tokens: {
      2: {
        id: 2,
        token: '2f98091c2f81da13e4569db50e51898a4d769450',
      },
      3: {
        id: 3,
        token: 'b072d7de3c01015142d8db7b3ed8c3dfacbf9258',
      },
      4: {
        id: 4,
        token: '307cc7446747cbe8ef7c64e111acfddb2bad88c1',
      },
      5: {
        id: 5,
        token: 'fcfae571147c6a8faa1e1abd4e1783064b0e3787',
      },
    },
    usernames: {
      'hector_emanuel': 2,
      'yasser': 3,
      'duran': 4,
      'xavier': 5,
    },
  },
  mutations: {
    setUser(state, user) {
      state.user = user;
      state.user.token = state.tokens[user.id].token;
    },
    setUserImg(state, img) {
      state.profileData.avatar = img;
    },
    setUserBanner(state, img) {
      state.profileData.banner = img;
    },
    clearUser(state) {
      state.user = null;
    },
    setProfileData(state, data) {
      state.profileData = data;
    },
  },
  actions: {
    loginUser({ commit }, user) {
      commit("setUser", user);
    },
  },
  getters: {
    user: (state) => state.user,
    getTokenById: (state) => (id) => {
      return state.tokens[id].token;
    },
    getIdByUsername: (state) => (username) => {
      return state.usernames[username];
    },
  },
  plugins: [createPersistedState()],
});