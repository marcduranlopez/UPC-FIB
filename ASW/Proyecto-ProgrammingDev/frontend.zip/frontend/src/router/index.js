// Composables
import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'blog',
    component: () => import('@/views/blog.vue'),
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/login.vue'),
  },
  {
    path: '/users/:user_id',
    name: 'profile',
    component: () => import('@/views/user.vue'),
  },  
  {
    path: '/users/:user_id/edit',
    name: 'edit_user',
    component: () => import('@/views/edit_user.vue'),
  },
  {
    path: '/communities',
    name: 'communities',
    component: () => import('@/views/communities.vue'),
  },
  {
    path: '/communities/:community_id',
    name: 'community',
    component: () => import('@/views/community.vue'),
  },  
  {
    path: '/create_community',
    name: 'create_community',
    component: () => import('@/views/create_community.vue'),
  },
  {
    path: '/posts/create',
    name: 'create_post',
    component: () => import('@/views/create_post.vue'),
  }, 
  {
    path: '/posts/:post_id',
    name: 'post',
    component: () => import('@/views/post.vue'),
  },  
  {
    path: '/posts/:post_id/edit',
    name: 'edit_post',
    component: () => import('@/views/edit_post.vue'),
  },
  {
    path: '/search',
    name: 'search',
    component: () => import('@/views/search.vue'),
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
})

export default router
