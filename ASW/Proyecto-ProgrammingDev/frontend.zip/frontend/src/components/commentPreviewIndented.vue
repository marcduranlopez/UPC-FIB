<template>
    <v-card v-if="item.post"
    :class="`my-3 mx-3 pa-2 ml-${1 + item.indentation * 5}`"
      elevation="6"
    >
      <v-row>
        <v-col cols="12">
          <v-card-title style="overflow: hidden">
            <v-row class="w-100">
              <v-col>
                <a :href="'/users/' + $store.getters.getIdByUsername(item.user_owner) + '/'" class="text-primary" style="font-size: 1rem;">
                  <strong>@{{ item.user_owner }}</strong>
                </a>
              </v-col>
              <v-col>
                <span style="font-size: 1rem;">
                  <strong>Post: </strong>
                </span>
                <a :href="'/posts/' + item.post.id + '/'" class="text-primary" style="font-size: 1rem;">
                  <strong>{{ item.post.title }} </strong>
                </a>
              </v-col>
              <v-col>
                <span style="font-size: 1rem;">
                  <strong>Comunidad: </strong>
                </span>
                <a :href="'/communities/' + item.post.community.id + '/'" class="text-primary" style="font-size: 1rem;">
                  <strong>#{{ item.post.community.id }}</strong><strong v-if="item.post.community.name"> ({{ item.post.community.name }})</strong>
                </a>
              </v-col>
              <v-col class="text-end">
                <p style="font-size: 1rem; display: inline;" class="mr-4">
                  <strong><em>{{ transformDate(item.created_at) }}</em></strong>
                </p>
                <v-icon class="mx-2">mdi-message-reply-outline</v-icon>
                <strong>{{ item.total_responses }}</strong>
              </v-col>
            </v-row>
          </v-card-title>
          <v-divider class="mr-2" />
          <v-card-text>
            <p style="font-size: 1.25rem">{{ acortarTexto(body) }}</p>
            <v-row class="mt-4 flex-nowrap align-center">
              <v-col cols="1" style="min-width: 160px;">
                <v-row class="flex-nowrap align-center">
                  <v-col>
                    <v-btn @click="vote('positive')" :disabled="$store.getters.user === null" rounded="xl" icon="mdi-thumb-up" size="40"> </v-btn>
                  </v-col>
                  <v-col>
                    <strong>{{
                      numVotes
                    }}</strong>
                  </v-col>
                  <v-col>
                    <v-btn @click="vote('negative')" :disabled="$store.getters.user === null" rounded="xl" icon="mdi-thumb-down" size="40"></v-btn>
                  </v-col>
                  <div v-if="$store.getters.user !== null" style="display: flex;">
                      <v-col>
                        <v-btn icon="mdi-reply" rounded="xl" size="40" @click="toggleReplyForm('reply')"></v-btn>
                      </v-col>
                    <div v-if="item.user_owner==$store.state.profileData.username" style="display: flex;">
                      <v-col>
                        <v-btn icon="mdi-pencil" rounded="xl" size="40" @click="toggleReplyForm('edit')"></v-btn>
                      </v-col>
                      <v-col>
                        <v-btn @click="delete_comment" icon="mdi-trash-can" rounded="xl" size="40"></v-btn>
                      </v-col>
                    </div>
                      <v-col>
                        <v-btn icon="mdi-star" @click="save_comment" rounded="xl" size="40"></v-btn>
                      </v-col>
                  </div>
                </v-row>
              </v-col>
            </v-row>
            <v-card v-if="showReplyForm" class="my-4">
              <v-card-text>
                <v-text-field
                  v-model="replyText"
                  label="Escribe tu comentario"
                ></v-text-field>
              </v-card-text>
              <v-card-actions>
                <v-btn v-if="action=='reply'" @click="publicarComentario">Publicar</v-btn>
                <v-btn v-else @click="editarComentario">Editar</v-btn>
                <v-btn @click="cancelarRespuesta">Cancelar</v-btn>
              </v-card-actions>
            </v-card>
          </v-card-text>
        </v-col>
      </v-row>
    </v-card>
  </template>

  <script setup>
    import axios from 'axios';
  </script>

  <script>
  export default {
    data() {
      return {
        showReplyForm: false,
        replyText: '',
        numVotes: this.item.total_votes,
        body: this.item.body,
        action: '',
      }
    },
    props: {
      item: {
        type: Object,
      },
    },
    methods: {
      save_comment() {
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
        let config = {
          headers: {
            'Authorization': `Token ${token}`,
          }
        }
        axios.post(`https://asw-proj.fly.dev/api/comments/${this.item.id}/save/`, null, config)
          .then(response => {
            
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
      },
      vote(type) {
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
        let requestBody = {
          'type': type,
        };
        let config = {
          headers: {
            'Authorization': `Token ${token}`,
          }
        }
        axios.post(`https://asw-proj.fly.dev/api/comments/${this.item.id}/vote/`, requestBody, config)
          .then(response => {
            this.numVotes = response.data.total_votes;
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
      },
      toggleReplyForm(action) {
        this.showReplyForm = !this.showReplyForm
        this.action = action;
      },
      publicarComentario() {
        if (this.replyText.length > 0) {
          let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
          let requestBody = {
            'body': this.replyText,
          };
          let config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          };
          axios.post(`https://asw-proj.fly.dev/api/comments/${this.item.id}/responses/`, requestBody, config)
          .then(response => {
            this.$emit('someCommentEvent');
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
        }
        this.cancelarRespuesta()
      },
      editarComentario() {
        if (this.replyText.length > 0) {
          let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
          let requestBody = {
            'body': this.replyText,
          };
          let config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          };
          axios.put(`https://asw-proj.fly.dev/api/comments/${this.item.id}/`, requestBody, config)
          .then(response => {
            this.body = response.data.body;
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
        }
        this.cancelarRespuesta()
      },
      delete_comment() {
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
        let config = {
          headers: {
            'Authorization': `Token ${token}`,
          }
        };
        axios.delete(`https://asw-proj.fly.dev/api/coments/${this.item.id}/`, config)
          .then(response => {
            this.$emit('someCommentEvent');
          })
          .catch(error => {
            console.error('Error al obtener datos:', error);
          });
      },
      cancelarRespuesta() {
        this.showReplyForm = false
        this.replyText = ''
      },
      transformDate(date) {
        const dateObj = new Date(date);
        const formatOptions = {
          weekday: "short",
          month: "long",
          day: "numeric",
        };
        const formatter = new Intl.DateTimeFormat("ca-ES", formatOptions);
        return formatter.format(dateObj);
      },
      acortarTexto(texto) {
        if (!texto) return null;
        const palabras = texto.split(" ");
        const maxPalabras = 25;
        if (palabras.length > maxPalabras) {
          const textoAcortado = palabras.slice(0, maxPalabras).join(" ");
          return textoAcortado + "...";
        }
        return texto;
      },
    },
  };
  </script>
  
  <style scoped>
  .dates {
    display: inline-block;
    margin-left: 1rem;
    font-size: 0.6em;
  }
  
  .flex-row {
    display: flex;
    flex-direction: row;
    align-items: start;
    justify-content: space-between;
  }
  </style>
  