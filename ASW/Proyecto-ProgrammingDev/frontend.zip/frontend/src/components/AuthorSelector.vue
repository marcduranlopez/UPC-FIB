<template>
  <v-container>
    <v-select 
      v-model="opcionSeleccionada"
      :items="opciones"
      label="Creador/a"
      class="custom-select"
      @update:model-value="emitAuthorChange"
    ></v-select>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      opcionSeleccionada: 'Todo',
      opciones: ['Todo', 'hector_emanuel', 'yasser', 'duran', 'xavier'],
    };
  },
  methods: {
    emitAuthorChange() {
      if (this.opcionSeleccionada != "Todo") this.$emit('authorEvent', this.$store.getters.getIdByUsername(this.opcionSeleccionada));
      else this.$emit('authorEvent', 'Todo');
    },
  },
};
</script>

<style scoped>
.custom-select {
  width: 250px; /* Ajusta el ancho según tus necesidades */
}
</style>

