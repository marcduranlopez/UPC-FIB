<template>
  <v-col>
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12">
        <div v-if="items.length === 0" style="text-align: left; font-size: 1.25rem;">
          <v-chip class="mr-2" size="large"> No hi ha resultats. </v-chip>
        </div>
          <v-list v-if="items.length > 0">
            <v-list-item v-for="(item, index) in items" :key="item" class="text-start">
              <postPreview v-if="typeOfList === 'posts'" :item="item" />
              <commentPreviewIndented v-else :item="item" :index="index" @someCommentEvent="handleSomeCommentEvent"/>
            </v-list-item>
          </v-list>
      </v-col>
    </v-container>
  </v-col>
</template>

<script>
import postPreview from "@/components/postPreview.vue";
import commentPreviewIndented from "@/components/commentPreviewIndented.vue";

export default {
  name: "listOfItems",
  components: {
    postPreview,
    commentPreviewIndented,
  },
  data() {
    return {
    };
  },
  props: {
    items: {
      type: Array,
    },
    typeOfList: String,
  },
  methods: {
    handleSomeCommentEvent() {
      this.$emit('commentEvent');
    }
  },
};
</script>
