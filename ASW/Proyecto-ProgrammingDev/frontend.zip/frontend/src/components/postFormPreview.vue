<template>
 <v-col>
    <h1 v-if="typeOfForm == 'create'" style="color: #000000" class="my-5 ml-5">Crear publicación</h1>
    <h1 v-else-if="typeOfForm == 'edit'" style="color: #000000" class="my-5 ml-5">Editar publicación</h1>
    <v-container class="d-flex justify-center align-center">
      <v-col cols="12">
        <v-card :loading="loading">
          <v-card-text v-if="loading == true">Loading...</v-card-text>
            <v-card-text v-else>
                <v-row class="mt- mx- align-center">
                  <v-col class="text-left">
                    <v-alert v-if="isTitleEmpty" type="error">El título no puede estar vacío</v-alert>
                    <v-textarea v-model="title" label="Título (*)"  placeholder="Escriba aquí..." rows="2" outlined no-resize @keydown.enter.prevent :maxlength=150></v-textarea>
                    <v-alert v-if="!isValidURL" type="error">La URL tiene que seguir un formato adecuado</v-alert>
                    <v-textarea v-model="url" label="URL"  placeholder="Escriba aquí..." rows="2" outlined no-resize @keydown.enter.prevent :maxlength=500></v-textarea>
                    <v-textarea v-model="body" label="Cuerpo"  placeholder="Escriba aquí..." rows="5" outlined :maxlength=1000></v-textarea>
                    <v-select v-model="selectedcommunity" :items="communities" label="Comunidad (*)" ></v-select>
                    <div v-if="selectedcommunity"> <p>Comunidad: {{ selectedcommunity }}</p></div>
                    <v-btn v-if="typeOfForm == 'create'" variant="text" icon="mdi-upload" color="green" @click="createPost()"></v-btn>
                    <v-btn v-else-if="typeOfForm == 'edit'" variant="text" icon="mdi-pencil" color="green" @click="editPost()"></v-btn>
                  </v-col>
                </v-row>  
              </v-card-text>
        </v-card>
      </v-col>
    </v-container>
  </v-col>
</template>



<script setup>
import axios from "axios";
</script>


  
<script>
export default {
  data() {
    return {
      communities: [],
      loading: false,
      title: null,
      url: null,
      body: null,
     selectedcommunity: null,
    };
  },
  props: {
    item: {
      type: Object,
    },
    typeOfForm: String,
  },
  computed: {
    isTitleEmpty() {
      return !this.title;
    },
    isValidURL() {
      const urlRegex = /^(ftp|http|https):\/\/[^ "]+$/;
      return !this.url ||  (this.url && urlRegex.test(this.url));
    }
  },
  created() {
    this.loading = true;
  },
  mounted() {
     this.getCommunities();
     if (this.typeOfForm == "edit" && this.item != null) {
      this.title = this.item.title;
      this.url = this.item.url;
      this.body = this.item.description;
      this.selectedcommunity = this.item.community;
     }
    },
  methods: {
    handleClick(path, id) {
        window.location.pathname = path + id;
      },
    getCommunities() {
      axios
        .get(
          "https://asw-proj.fly.dev/api/communities/", {
          headers: {
            "Content-Type": "application/json",
          },
        })
        .then((response) => {
          let coms = response.data.results;
          for (let i = 0; i < response.data.results.length; ++i) {
            this.communities[i] = coms[i].id;
          }
          this.selectedcommunity = this.communities[0];

          if (this.typeOfForm == "edit" && this.item != null) {
              this.title = this.item.title;
              this.url = this.item.url;
              this.body = this.item.description;
              this.selectedcommunity = this.item.community.id;
            }
          this.loading = false;
        })
        .catch((error) => {
        });
    },
    createPost() {
      if (this.title && this.selectedcommunity && this.isValidURL) {
        let id;
        let postData = {
          title: this.title,
          url: this.url,
          description: this.body,
          community: this.selectedcommunity, 
        };
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
         let config = {
            headers: {
              Authorization: `Token ${token}`,
            }
          }
          axios.post(`https://asw-proj.fly.dev/api/posts/`, postData, config)
          .then((response) => {
            console.log(response.data );
            id = response.data.id;
            console.log(id)
            this.handleClick('/posts/', id);
          })
          .catch((error) => {
            console.error("Error de axios:", error);
          });
          

          
      }
    },
    editPost() {
      if (this.isValidURL) {
      
        let postData = {
          title: this.title,
          url: this.url,
          description: this.body,
          community: this.selectedcommunity, 
        };
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
         let config = {
            headers: {
              Authorization: `Token ${token}`,
            }
          }
          let id = this.item.id;
          axios.put(`https://asw-proj.fly.dev/api/posts/${id}/`, postData, config)
          .then((response) => {
          })
          .catch((error) => {
            console.error("Error de axios:", error);
          });
          this.handleClick('/posts/', this.item.id);

      }
    },

    
  }
};
</script>