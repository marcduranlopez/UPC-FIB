<!-- ======================================================================= -->
<!--                   COMPONENTE MUESTRA AVATAR Y EDITAR                    -->
<!-- ======================================================================= -->

<template>
  <!-- ======================== AVATAR Y ICONO EDITAR ======================== -->
  <div v-if="type === 'avatar'" class="position-relative">
    <div class="avatar-container">
      <v-avatar color="grey" size="150" class="m-auto" style="position: relative">
      <v-img cover :src="imageSource"></v-img>
    </v-avatar>

    <v-btn @click="openFileInput" icon style="position: absolute; bottom: -10px; right: 0; z-index: 2">
      <v-icon>mdi-pencil</v-icon>
    </v-btn>
    </div>
    

    <v-file-input ref="fileInput" :accept="'image/jpeg, image/png'" :v-model="img" style="display: none"
      @change="handleFileChange"></v-file-input>
  </div>
  <div v-else style="background-color: grey; height:200px; border-radius: 10px; overflow: hidden;">
    <div class="position-relative banner-img">
      <v-img cover :src="bannerSource" class="center-image"></v-img>  
      <v-btn @click="openFileInput" icon class="edit-btn">
        <v-icon>mdi-pencil</v-icon>
      </v-btn>
    </div>
    <v-file-input ref="fileInput" :accept="'image/jpeg, image/png'" :v-model="img" style="display: none"
      @change="handleBannerChange"></v-file-input>
  </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  props: {
    img: String, //Recibe datos de la vista padre
    type: String,
    banner: String,
  },
  methods: {
    openFileInput() {
      this.$refs.fileInput.click();
    },
    handleFileChange(event) {
      const file = event.target.files[0];
      this.$emit("update-img", file); //Envia datos a la vista padre
    },
    handleBannerChange(event) {
      const file = event.target.files[0];
      this.$emit("update-banner", file); //Envia datos a la vista padre
    },
  },
  computed: {
    imageSource() {
      // Verificar si 'imatge' es una URL o un objeto File
      if (this.img instanceof File) {
        // Si es un objeto File, usar URL.createObjectURL para generar una URL temporal
        return URL.createObjectURL(this.img);
      } else {
        // Si es una URL, simplemente devolver la URL
        return this.img;
      }
    },
    bannerSource() {
      // Verificar si 'imatge' es una URL o un objeto File
      if (this.banner instanceof File) {
        // Si es un objeto File, usar URL.createObjectURL para generar una URL temporal
        return URL.createObjectURL(this.banner);
      } else {
        // Si es una URL, simplemente devolver la URL
        return this.banner;
      }
    },
  }
};
</script>

<style>
  .edit-btn {
    position: absolute;
    top: 20px;
    right: -760px;
  }

  @media screen and (min-width: 1440px) {
    .edit-btn {
      top: 30px;
      left: 90%;
  }
  }

  @media screen and (min-width: 1280px) {
    .edit-btn {
      top: 30px;
      left: 90%
  }
  }
  
  @media screen and (max-width: 1280px) {
    .edit-btn {
    right: -530px;
  }
  }
  
  @media screen and (max-width: 768px) {
    .edit-btn {
    right: -290px;
  }
  }
</style>