<template>
  <v-container>
    <v-btn @click="anterior" :disabled="page === 1" class="mr-2">Anterior</v-btn>
    <v-btn @click="siguiente">Siguiente</v-btn>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
    };
  },
  props: {
    page: Number,
  },
  methods: {
    anterior() {
      this.$emit('paginationEvent', -1);
    },
    siguiente() {
      this.$emit('paginationEvent', 1);
    },
  },
};
</script>

