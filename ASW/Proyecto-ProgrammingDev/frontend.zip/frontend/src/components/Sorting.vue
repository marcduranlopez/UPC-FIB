<template>
  <v-container>
    <v-select 
      v-model="opcionSeleccionada"
      :items="opciones"
      label="Tipo de orden"
      class="custom-select"
      @update:model-value="emitSortingChange"
    ></v-select>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      opcionSeleccionada: 'Nuevo',
      opciones: ['Nuevo', 'Antiguo', 'Más Comentado', 'El mejor de todos los tiempos'],
    };
  },
  methods: {
    emitSortingChange() {
      this.$emit('sortingEvent', this.opcionSeleccionada);
    },
  },
};
</script>

<style scoped>
.custom-select {
  width: 250px; /* Ajusta el ancho según tus necesidades */
}
</style>

