<template>
  <v-row class="mt- mx- align-center">
  </v-row>
  <v-card :loading="loading">
    <v-card-text v-if="loading == true">Loading...</v-card-text>
    <v-card-text v-else>
      <v-card class="my-3 mx-3 pa-2" elevation="6">
        <v-row class="mt- mx- align-center">
          <v-col class="text-left">
            <v-btn variant="text" color="primary">
              <v-card-title @click="handleClick('/posts/', item.id)">{{ item.title }}</v-card-title>
            </v-btn>
          </v-col>
        </v-row>
        <v-col>
        <v-card-text v-if="item.description" class="mx- mt-">{{ item.description}}</v-card-text>
        <v-card-text v-else class="mx- mt-"><em>No n'hi ha descripció</em></v-card-text>
  
      </v-col>
          <v-row class="mt-auto ml-auto mx-auto" >
            <v-col class="text-left">
                <v-row align="center" >
                    <v-btn
                      variant="text"
                      icon="mdi-thumb-up"
                      :color="getButtonColor('like')"
                      @click="likePost()"
                    ></v-btn>
                    <span>{{ item.total_votes }}</span> 
                    <v-btn
                      variant="text"
                      icon="mdi-thumb-down"
                      :color="getButtonColor('dislike')"
                      @click="disLikePost()"
                    ></v-btn>
  
                <!-- TODO link to users/post.user_owner.id hacer una petición? -->
                    <v-btn
                      variant="text"
                      color="primary"
                      @click="handleClick('/users/', id)"
                    >
                      <v-icon class="custom-icon" left>mdi-account</v-icon>
                      <span>@{{ item.user_owner }}</span>
                   </v-btn>
  
                    <v-btn
                      variant="text"
                      color="primary"
                      @click="handleClick('/communities/', item.community.id)"
                    >
                      <v-icon class="custom-icon" left>mdi-account-group</v-icon>
                      <span>{{ item.community.id }}</span>
                   </v-btn>
  
                    <v-icon class="mx-2">mdi-comment-outline</v-icon>
                    <strong>{{ item.total_comments }}</strong>
                    
                  
                  <v-card-text class="text-left"
                  ><v-icon class="mr-2">mdi-calendar-clock</v-icon>
                  <strong>{{
                    new Date(item.created_at).toLocaleDateString("es-ES")
                  }}</strong></v-card-text>
                  
                </v-row>
              </v-col>
                  <v-btn            
                      v-if="item.user_owner == username"       
                      outlined 
                      color="red"
                      @click="deletePost()"
                    >
                    <v-icon class="custom-icon" left>mdi-delete</v-icon>
                  </v-btn>
                  <v-btn
                      v-if="item.user_owner == username"                  
                      outlined 
                      color="yellow"
                      @click="handleClick('/posts/', item.id + '/edit')"
                    >
                    <v-icon class="custom-icon" left>mdi-pencil</v-icon>
                  </v-btn>
                  <v-btn                   
                      outlined 
                      color="green"
                      @click="savePost()"
                    >
                    <v-icon v-if="save == true" class="custom-icon" left>mdi-bookmark-check-outline</v-icon>
                    <v-icon v-else="save == true" class="custom-icon" left>mdi-bookmark-check</v-icon>
                  </v-btn>
              </v-row>  
    </v-card>
  </v-card-text>
  </v-card>
</template>
  

<script setup>
import axios from "axios";
</script>
  

<script>
export default {
  data() {
    return {
      username: null,
      id: null,
      loading: false,
      save: true,
      like: false,
      dislike: false,
    };
  },
  props: {
    item: {
      type: Object,
    },
    created() {
     this.loading = true;
   },
  },
    mounted() {
    this.getLikedPost();
    this.getDisLikedPost();
    this.getPostsSaved();
    this.getUsers();
    this.getUserInfo();
  },
    methods: {
      handleClick(path, id) {
        window.location.pathname = path + id;
      },
      getButtonColor(button) {
      switch (button) {
        case 'like':
          return this.like == true ? 'primary' : 'null';
        case 'dislike':
         return this.dislike == true ? 'primary' : 'null';
        default:
          return 'null';
      }
    },
      transformDate(date) {
        const dateObj = new Date(date);
        const formatOptions = {
          weekday: "short",
          month: "long",
          day: "numeric",
        };
        const formatter = new Intl.DateTimeFormat("ca-ES", formatOptions);
        return formatter.format(dateObj);
      },
      acortarTexto(texto) {
        if (!texto) return null;
        const palabras = texto.split(" ");
        const maxPalabras = 25;
        if (palabras.length > maxPalabras) {
          const textoAcortado = palabras.slice(0, maxPalabras).join(" ");
          return textoAcortado + "...";
        }
        return texto;
      },
      getPostsSaved() {
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
         let config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          }
        axios
          .get(`https://asw-proj.fly.dev/api/posts/saved/`, {
            headers: {
              'Authorization': `Token ${token}`,
              "Content-Type": "application/json",
            },
          })
          .then((response) => {
              for (let i = 0; i < response.data.length; i++) {
                if (this.item.id == response.data[i].id) {
                  this.save = false;
                }
              }
          })
          .catch((error) => {
            console.error("Error al obtener los posts guardados:", error);
          });
      },
      getUsers() {
        axios
          .get(`https://asw-proj.fly.dev/api/users/`, {
            headers: {
              "Content-Type": "application/json",
            },
          })
          .then((response) => {
            for (let i = 0; i < response.data.results.length; i++) {
              if (response.data.results[i].username == this.item.user_owner) {
                  this.id = response.data.results[i].id;
                  console.log(this.id)
              }
            }
          })
          .catch((error) => {
            console.error("Error al obtener los datos del usuario:", error);
          });
    },
      getUserInfo() {
        axios
          .get(`https://asw-proj.fly.dev/api/users/${this.$store.getters.user.id}/`, {
            headers: {
              "Content-Type": "application/json",
            },
          })
          .then((response) => {
            this.username = response.data.username;
            this.loading = false;
          })
          .catch((error) => {
            console.error("Error al obtener los datos del usuario:", error);
          });

    },
    deletePost() {
      let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
      let config = {
        headers: {
          'Authorization': `Token ${token}`,
        }
      }
      axios.delete(`https://asw-proj.fly.dev/api/posts/${this.item.id}/`, config)
          .then((response) => {
            if (this.$route.params.post_id != null) {
              this.handleClick('/', "");
            }
            else {
              this.handleClick(this.$route.path, "");
            }
           
          })
          .catch((error) => {
            console.error("Error de axios:", error);
          });
    },
    savePost() {
      let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
         let config = {
            headers: {
              'Authorization': `Token ${token}`,
            }
          }

          if (this.save) {
            axios.post(`https://asw-proj.fly.dev/api/posts/${this.item.id}/save/`, null, config)
          .then((response) => {
            this.save = !this.save;
           
          })
          .catch((error) => {
            console.error("Error de axios:", error);
          });
          }
          else {
            axios.post(`https://asw-proj.fly.dev/api/posts/${this.item.id}/unsave/`, null, config)
          .then((response) => {
            this.save = !this.save;
           
          })
          .catch((error) => {
            console.error("Error de axios:", error);
          });
          }
      },
      getLikedPost() {
        let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
    
          axios
          .get(
          `https://asw-proj.fly.dev/api/posts/${this.item.id}/like/`, {
          headers: {
            'Authorization': `Token ${token}`,
          },
        })
        .then((response) => {
          this.like = true;
          
        })
        .catch((error) => {
          // Maneja errores aquí
          if (error.code == 'ERR_BAD_REQUEST') {
            this.like = false;
          }
        });
    },
    getDisLikedPost() {
      let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
      axios
          .get(
          `https://asw-proj.fly.dev/api/posts/${this.item.id}/dislike/`, {
          headers: {
            'Authorization': `Token ${token}`,
          },
        })
        .then((response) => {
          this.dislike = true;
          
        })
        .catch((error) => {
          // Maneja errores aquí
          if (error.code == 'ERR_BAD_REQUEST') {
            this.dislike = false;
          }
        });
    },
    likePost() {
      let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
        let config = {
          headers: {
            Authorization: `Token ${token}`,
          }
        }
        axios.post(`https://asw-proj.fly.dev/api/posts/${this.item.id}/like/`, null, config)
        .then((response) => {
          this.handleClick('/posts/', this.item.id);
        })
        .catch((error) => {
          // Maneja errores aquí
          console.error("Error de axios:", error);
        });
    },
    disLikePost() {
      let token = this.$store.getters.getTokenById(this.$store.getters.user.id);
        let config = {
          headers: {
            Authorization: `Token ${token}`,
          }
        }
        axios.post(`https://asw-proj.fly.dev/api/posts/${this.item.id}/dislike/`, null, config)
        .then((response) => {
          this.handleClick('/posts/', this.item.id);
        })
        .catch((error) => {
          // Maneja errores aquí
          console.error("Error de axios:", error);
        });
    },
  }
}
  </script>
  
  <style scoped>
  .dates {
    display: inline-block;
    margin-left: 1rem;
    font-size: 0.6em;
  }
  
  .flex-row {
    display: flex;
    flex-direction: row;
    align-items: start;
    justify-content: space-between;
  }
  
  .custom-link-color {
    color: teal; 
  }
  
  .custom-icon {
    margin-right: 2px; 
  }
  </style>

