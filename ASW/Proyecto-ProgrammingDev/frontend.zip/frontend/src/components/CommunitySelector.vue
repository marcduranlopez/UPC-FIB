<template>
  <v-container>
    <v-select 
      v-model="opcionSeleccionada"
      :items="opciones"
      label="Comunidad"
      class="custom-select"
      @update:model-value="emitCommunityChange"
    ></v-select>
  </v-container>
</template>

<script setup>
  import axios from "axios";
</script>

<script>

export default {
  data() {
    return {
      opcionSeleccionada: 'Todo',
      opciones: ['Todo'],
      identificadores: ['padding'],
    };
  },
  created() {
    axios.get("https://asw-proj.fly.dev/api/communities/")
      .then(response => {
          response.data.results.forEach(objeto => {
            this.opciones.push('#' + objeto.id + ' (' + (objeto.name !== null ? objeto.name : '') + ')');
            this.identificadores.push(objeto.id);
          })
      })
      .catch(error => {
        console.error('Error al obtener datos:', error);
      });
  },
  methods: {
    emitCommunityChange() {
      if (this.opcionSeleccionada != 'Todo') this.$emit('communityEvent', this.identificadores[this.opciones.indexOf(this.opcionSeleccionada)]);
      else this.$emit('communityEvent', 'Todo');
    },
  },
};
</script>

<style scoped>
.custom-select {
  width: 250px; /* Ajusta el ancho según tus necesidades */
}
</style>

