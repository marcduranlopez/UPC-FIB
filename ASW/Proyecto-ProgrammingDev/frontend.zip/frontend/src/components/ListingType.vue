<template>
  <v-container>
    <v-btn-toggle 
      v-model="selectedOption"
      mandatory
      group
      @update:model-value="emitListingTypeChange"
    >
      <v-btn value="local">
        Local
      </v-btn>
      <v-btn value="subscribed" :disabled="$store.getters.user === null">
        Suscrito
      </v-btn>
    </v-btn-toggle>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      selectedOption: "local",
    };
  },
  methods: {
    emitListingTypeChange() {
      this.$emit('listingTypeEvent', this.selectedOption);
    },
  },
};
</script>