<template>
  <v-container>
    <v-btn-toggle 
      v-model="selectedOption"
      mandatory
      group
      @update:model-value="emitDataTypeChange"
    >
      <v-btn value="posts">
        Publicaciones
      </v-btn>
      <v-btn value="comments">
        Comentarios
      </v-btn>
    </v-btn-toggle>
  </v-container>
</template>

<script>
export default {
  data() {
    return {
      selectedOption: "posts",
    };
  },
  methods: {
    emitDataTypeChange() {
      this.$emit('dataTypeEvent', this.selectedOption);
    },
  },
};
</script>