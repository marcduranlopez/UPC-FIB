## Lab Session #03

Students:

* Duran, Marc

* Pera, Miguel