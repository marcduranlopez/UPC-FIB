package fib.asw.waslab03;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.hc.client5.http.fluent.Request;
import org.apache.hc.core5.http.ContentType;
import org.json.JSONArray;
import org.json.JSONObject;

public class Tasca_6 {
	
	private static final String LOCALE = "ca";

	public static void main(String[] args) {
		JSONObject body = new JSONObject();

		String URI = "https://mastodont.cat/api/v1/trends/tags?limit=10";
		String TOKEN = Token.get();

		try {
			String output = Request.get(URI)
					.bodyString(body.toString(), ContentType.parse("application/json"))
					.addHeader("Authorization","Bearer "+TOKEN)
					.execute()
					.returnContent()
					.asString();

			JSONArray jsonArray = new JSONArray(output); 
			
			SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd MMMM 'de' yyyy 'a les' HH:mm:ss", new Locale(LOCALE));
			String now = sdf.format(new Date());

			System.out.println("Els 10 tags més populars a Mastodon[" + now +"]");
			
		    for (int i = 0; i < jsonArray.length(); i++) {
		        JSONObject result = jsonArray.getJSONObject(i);
		        String content = result.getString("name");
		        
		        System.out.println("*************************************************");
		        System.out.println("* Tag: " + content);
                System.out.println("*************************************************");
		        
		        String TWEET_TAGS = "https://mastodont.cat/api/v1/timelines/tag/" + content + "?limit=5";
		        
		        String output2 = Request.get(TWEET_TAGS)
						.bodyString(body.toString(), ContentType.parse("application/json"))
						.addHeader("Authorization","Bearer "+TOKEN)
						.execute()
						.returnContent()
						.asString();
		        //System.out.println(output2);
		        
		        JSONArray jsonArray2 = new JSONArray(output2);
			    for (int j = 0; j < jsonArray2.length(); j++) {
			    	JSONObject result2 = jsonArray2.getJSONObject(j);
			    	JSONObject account = result2.getJSONObject("account");
			    	String authorDisplayName = account.getString("display_name");
                    String authorUsername = account.getString("acct");
                    String tweetContent = result2.getString("content");
			        
			        System.out.println("- " + authorDisplayName + " (" + authorUsername + "): " + tweetContent);
                    System.out.println("-------------------------------------------------");
			        
			    }
			    System.out.println();
			      
		    }
		    
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}


