package fib.asw.waslab03;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.hc.client5.http.fluent.Request;
import org.apache.hc.core5.http.ContentType;
import org.json.JSONArray;
import org.json.JSONObject;

public class Tasca_5 {

	public static void main(String[] args) {
		JSONObject body = new JSONObject();

		String URI = "https://mastodont.cat/api/v1/accounts/109862447110628983/statuses?limit=1";
		String TOKEN = Token.get();

		try {
			String output = Request.get(URI)
					.bodyString(body.toString(), ContentType.parse("application/json"))
					.addHeader("Authorization","Bearer "+TOKEN)
					.execute()
					.returnContent()
					.asString();

			JSONArray jsonArray = new JSONArray(output); 
			String id = "";
		    for (int i = 0; i < jsonArray.length(); i++) {
		        JSONObject result = jsonArray.getJSONObject(i);
		        id = result.getString("id");
		        String content = result.getString("content");
		        System.out.println(content);
		    }
		    
		    String BOOST = "https://mastodont.cat/api/v1/statuses/" + id + "/reblog";
		    
		    String boost = Request.post(BOOST)
					.bodyString(body.toString(), ContentType.parse("application/json"))
					.addHeader("Authorization","Bearer "+TOKEN)
					.execute()
					.returnContent()
					.asString();
	        //System.out.println(boost);
	        
		    

		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
