## Lab Session #01

Students: 

* Duran, Marc

* Pera, Miguel
