package fib.asw.waslab01_cs;

import org.apache.hc.client5.http.fluent.Form;
import org.apache.hc.client5.http.fluent.Request;

//This code uses the Fluent API

public class SimpleFluentClient {

	private static String URI = "http://localhost:8080/waslab01_ss/";

	public final static void main(String[] args) throws Exception {
  	
	String idTweet = Request.post(URI)
	.bodyForm(Form.form().add("author",  "Java Client").add("tweet_text",  "Hardcoded message").build())
	.addHeader("Accept", "text/plain").execute().returnContent().asString();
	System.out.print(idTweet);
		
  	
	System.out.println(Request.get(URI).addHeader("Accept", "text/plain").execute().returnContent());
  	
  	/* Insert code for Task #5 here */
	Request.post(URI).addHeader("Accept", "text/plain")
	.bodyForm(Form.form().add("LastTweetId", idTweet).build()).execute();
  }
}