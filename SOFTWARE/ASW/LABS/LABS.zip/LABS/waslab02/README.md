## Lab Session #02

Students: 

* Duran, Marc

* Pera, Miguel